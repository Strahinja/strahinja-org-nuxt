
	README.TXT file for MiddleEarthWrite(tm) v1.03
	================================================

   1.0. Legal stuff

	MiddleEarthWrite is licensed by the terms of GNU GPL.
	This means that everyone has the freedom to change and
	distribute it without any refund to the author, but if
	changes occur, you must clearly state that it is modified,
	along with specifying the name of the original author.
	The complete source code must also be distributed with
	the program. Further information can be found in the files
	COPYING-sr-c-win1251.txt, COPYING-sr-l-ascii.txt
	or COPYING.txt.

	Tengwar and Cirth are the alphabets invented by late Prof. John
	Ronald Reuel Tolkien, so he is also meritorous for this program
	(I would rather say that the program is made BECAUSE OF his books).

   1.1. IMPORTANT!!!

	A TrueType fonts named Tengwar Parmaite and CirthErebor are included
	in the package, and they are of KEY importance for the normal
	operation of the program. Without that fonts (or some other tengwar
	and cirth fonts), MiddleEarthWrite will output something like this:
	j.D7T`V etc. So, before you start MiddleEarthWrite, please install the
	fonts like this (under the Windows operating system):
	  a) Unpack the archives Parmaite12.zip and cirth11.zip into some directory.
	  b) Start->Settings->Control Panel->Fonts->File->Install new font...
	     You will be presented a dialog. Check the `Copy fonts to Windows
	     directory' and browse to the directory where you unpacked
	     the archives. The names of the `Tengwar Parmaite (TrueType)'
	     and `Cirth Erebor (True Type)' fonts should appear in
	     the `List of fonts' list.
	  c) Double click the names of the fonts and they will be installed.
	Also included in the file tcurs100.zip is the font Tengwar Cursive,
	which is installed in the same way as Tengwar Parmaite. Tengwar
	Cursive can be used i.e. for the Ring inscription. There is also a
	test example, called ``test16 (Ring lore in Tengwar Cursive
	font).txt'', which is best viewed with the Tengwar Cursive font
	at 72pt.

   2. What's the use of this?

	The intended use of the program MiddleEarthWrite is to write texts
	in the alphabets from the books of John Ronald Reuel Tolkien.
	The program supports eleven transcription modes, of which six are
	tengwar: Quenya (Noldor), Sindarin/Adunaic (Mode of Arnor),
	Sindarin/Adunaic (Mode of Gondor), Sindarin (Mode of Beleriand),
	Westron/Black speech, English/Westron, and five are cirth:
	Sindarin (Angerthas Daeron), Sindarin/Quenya (Angerthas Eregion),
	Khuzdul (Angerthas Moria), Khuzdul (Angerthas Erebor), and
	English/Anglosaxon.

	MiddleEarthWrite is a program developed under Delphi 6.0. I am not
	familiar with whether it can be compiled under some
	other version of Delphi.

   3. How to compile MiddleEarthWrite from source code?

	First, you need to obtain the source code by writing an email
	to me at mr99164@alas.matf.bg.ac.yu. Then, I will send the
	source code to you. No payment is required. I didn't include
	the source code because I didn't want the dist archive to
	be too heavy on size (1.1M+).

	Then...

	In order to compile MiddleEarthWrite, you need to:
	  a) Unpack the archive to a directory.
	  b) Obtain and install JEDI-VCL (from http://www.delphi-jedi.org/)
	  c) Component->Install Component->Browse...
	  d) Locate MyJStFld.pas, Ok... Compile dclusr60.dpk
	You should be presented a dialog box that MyJvStarfield is
	registered.

	  e) Open MEW.bpg and compile it. That's it!

	Strahinya Radich,
	<mr99164@alas.matf.bg.ac.yu>

	In Beograd,
	March 3rd, 2002
