#include <stdio.h>
#include "strng.h"
#include "screen.h"
#include "timer.h"

void hello(void *);

#if ISBLND
#pragma warn -aus
#endif

main()
{
    // --------------- Implicitno ukljuceno baferisanje
    Screen scr( NULL );
    key_t ch;
    int i, j;
    const char *msg = "PROBA BAFERISANJA";

    //scr.setBright();
    scr.setColor(clBrightWhite);
    scr.outTextXY(string(msg),
		  scr.getWidth()/2-strlen(msg)/2,
		  scr.getHeight()/2);
    scr.update();
    do {
    ch = scr.getCh();
    } while (ch==kbNoKey);

    scr.clrScr();

    // --------------- Sa baferisanjem (brze)
    scr.setColor(clBrightWhite);
    scr.outTextXY(string("Sa baferisanjem..."), 5, scr.getHeight()-2);
    scr.update();

    for (i = 0; i < 5; i++)
	for (j = 0; j < 5; j++) {
	    scr.setColor(scr.randomColor());
	    scr.outTextXY(string("Hello, world!"), 5+j+i, 2+i);
	}
    for (i = 0; i < 5; i++)
	for (j = 5; j < 15; j++) {
	    scr.setColor(scr.randomColor());
	    scr.outTextXY(string("Hello, world!"), 5+j+i, 2+i);
	}
    scr.update();
    do {
    ch = scr.getCh();
    } while (ch==kbNoKey);

    // --------------- Iskljucivanje baferisanja
    scr.setDoubleBuff( false );

    // --------------- Bez baferisanja (sporije)
    scr.setColor(clBrightWhite);
    scr.outTextXY(string("Bez baferisanja..."), 5, scr.getHeight()-2);

    for (i = 0; i < 5; i++)
	for (j = 0; j < 5; j++) {
	    scr.setColor(scr.randomColor());
	    scr.outTextXY(string("Hello, world!"), 5+j+i, 2+i);
	}
    for (i = 0; i < 5; i++)
	for (j = 5; j < 15; j++) {
	    scr.setColor(scr.randomColor());
	    scr.outTextXY(string("Hello, world!"), 5+j+i, 2+i);
	}
    scr.update();
    do {
    ch = scr.getCh();
    } while (ch==kbNoKey);

    Timer t(&scr, &hello, true, false);
    Time end(2, 2000); // 4s
    Time raz;
    const char *tmsg = "PROBA TAJMERA";
    char buf[255];

    t.setTime(end);

    scr.setDoubleBuff(true);
    //scr.setBright();
    scr.setColor(clBrightWhite);
    scr.outTextXY(string(tmsg),
		  scr.getWidth()/2-strlen(tmsg)/2,
		  scr.getHeight()/2);
    scr.update();
    do {
    ch = scr.getCh();
    } while (ch==kbNoKey);

    scr.clrScr();
    scr.update();

    while (t.isActive()) {
	raz = t.period();
	raz = end - raz;
	sprintf( buf,
		 "Tajmer: %ld:%ld                ",
		 (long int)raz.sec,
		 (long int)raz.msec );
	scr.outTextXY(string(buf), 5, 6);
	t.doInLoop();
	scr.update();
    }

    scr.setColor( clBrightWhite );
    scr.outTextXY(string("Tajmer istekao!           "), 5, 6);
    scr.update();
    do {
    ch = scr.getCh();
    } while (ch==kbNoKey);

    scr.clrScr();
    scr.update();

    return 0;
}

void hello(void *param)
{
    if (param && ((Object *)param)->isA("Screen")) {
	((Screen *)param)->setColor(clBrightYellow);
	((Screen *)param)->outTextXY("Zdravo!", 5,
				     ((Screen *)param)->getHeight()-5);
    }
}
