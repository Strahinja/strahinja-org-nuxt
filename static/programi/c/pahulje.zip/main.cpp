/* -*- C++ -*- */
/******************************************/
/* P A H U L J E (c) 2001                 */
/*----------------------------------------*/
/*   Strahinja Radic,     ML 164/99       */
/*      <mr99164@alas.matf.bg.ac.yu>      */
/*   Milan Skaric,        MR 266/98       */
/*   Vladimir Raskovic,   MR 254/99       */
/*   Obrad Radosavljevic, ML 200/99       */
/******************************************/

#include "inifile.h"
#include "timer.h"
#include "screen.h"
#include "pahulje.h"

const size_t nItems = 4;

const char *menuItems[nItems] = {
    "        Nova igra        ",
    "   Ucitavanje pozicije   ",
    "         Igraci          ",
    "          Izlaz          "
};

const char *menuDesc[nItems] = {
    "Pocetak nove igre                               ",
    "Ucitavanje pozicije iz fajla i nastavljanje igre",
    "Zadavanje imena igraca                          ",
    "Izlaz iz programa                               "
};

const color_t menuColors[nItems] = {
    clBrightGreen,
    clBrightBlue,
    clBrightMagenta,
    clBrightRed
};

void naslov(Screen& s);
void meni(Screen& s, const size_t izb, const string& ig1, const string& ig2);
void unosIgraca(Screen& s, string *ig1, string *ig2);
void onSat(void *param);
void onPobed(void *param);

struct ScreenAndPob {
    Screen *scr;
    string *pob;
};

const size_t maxclrs = 4;
const color_t clrs[maxclrs] = {
   clBrightYellow,
   clBrightYellow,
   clBrightRed,
   clBrightRed
};
size_t clr = 0;
coord_t pom = 0;
signed char znak = 1;

main()
{
    Screen scr(NULL);
    IniFile settings(NULL, "pahulje.ini");
    Pahulje igra(&scr);
    key_t ch;
    int izbor = 0;
    string i1, i2, pobednik;
    Status pob;
    Timer sat(NULL, &onSat);
    Timer pobed(NULL, &onPobed);
    ScreenAndPob sap;

    settings.load();
    i1 = settings.find("Igraci", "Igrac1");
    if (i1.length() != 0)
	igra.setIme1(i1);
    else {
	igra.getIme1(&i1);
	settings.add("Igraci", "Igrac1", i1);
    }
    i2 = settings.find("Igraci", "Igrac2");
    if (i2.length() != 0)
	igra.setIme2(i2);
    else {
	igra.getIme2(&i2);
	settings.add("Igraci", "Igrac2", i2);
    }
    pobednik = settings.find("Igraci", "Pobednik");
    if (pobednik.length() == 0)
	pobednik = "Igrac";
    settings.add("Igraci", "Pobednik", pobednik);

    sat.setTime(Time(1,0));
    pobed.setTime(Time(1,500));
    do {
	meni(scr, izbor, i1, i2);
	scr.update();
        do {
	    ch = scr.getCh();
            sap.scr = &scr;
            sap.pob = &pobednik;
            sat.doInLoop(&scr);
            pobed.doInLoop(&sap);
        } while (ch == kbNoKey);
        scr.update();
	switch(ch) {
	    case kbUp: case 'k': case 'K':
	    case kbRight: case 'l': case 'L':
		izbor--;
		if (izbor == -1) izbor = nItems-1;
		break;
	    case kbDown: case 'j': case 'J':
	    case kbLeft: case 'h': case 'H':
		izbor++;
		if (((size_t)izbor) == nItems) izbor = 0;
		break;

	    case ' ': case kbEnter:
                sat.stop();
                pobed.stop();
		switch (izbor) {
		    case 0:
                    	pob = igra.pocni();
			scr.clrScr();
			meni(scr, izbor, i1, i2);
                        switch (pob) {
			    case IGRAC1:
				settings.add("Igraci", "Pobednik", i1);
				pobednik = i1;
				break;
			    case IGRAC2:
				settings.add("Igraci", "Pobednik", i2);
				pobednik = i2;
				break;
			    default: ;
                        }
			break;
		    case 1: break;
		    case 2:
			unosIgraca(scr, &i1, &i2);
			scr.clrScr();
			if (i1.length()==0) igra.getIme1(&i1);
			settings.add("Igraci", "Igrac1", i1);
			if (i2.length()==0) igra.getIme2(&i2);
                        settings.add("Igraci", "Igrac2", i2);
			igra.setIme1(i1);
			igra.setIme2(i2);
			meni(scr, izbor, i1, i2);
			break;
		    case 3:
			ch = kbEsc;
			break;
		}
                sat.reset();
                pobed.cont();
		break;

	    default:
		/*sprintf(msg, "0x%X", ch);
		  scr.setColor(clBrightYellow);
		  scr.outTextXY(msg, 5, scr.getHeight()-2);*/
		break;
	}
    } while (ch != 'q' && ch != 'Q' && ch != kbEsc);

    scr.clrScr();
    scr.update();

    return 0;
}

void naslov(Screen& s)
{
    char msg[255];
    s.setColor(clBrightWhite);
    sprintf(msg, "P A H U L J E (%s verzija), (c) SR, MS, VR, OR",
	    (const char *)s.screenType());
    s.outTextXY(msg, s.getWidth()/2-strlen(msg)/2-1, 0);
}

void meni(Screen& s, const size_t izb, const string& ig1, const string& ig2)
{
    size_t i;

    naslov(s);
    //s.setBright();
    for (i = 0; i < nItems; i++) {
	s.gotoXY(s.getWidth()/2-strlen(menuItems[i])/2-1,
		 5+3*i);
	s.setBlink( (izb == i) ? true : false );
	s.setColor( clBrightYellow, (izb == i) ? menuColors[i] : clBlack );
	s.outText(menuItems[i]);
	s.setBlink(false);
	s.setColor( clBrightYellow, clBlack );
	if (i==2) {
	    if (ig1) s.outTextXY(ig1, 1, s.whereY());
	    if (ig2) s.outTextXY(ig2, s.getWidth()-strlen(ig2),
				 s.whereY());
	}
    }
    s.setReverse(false);
    s.setColor(clBrightWhite);
    //s.setBright();
    s.outTextXY(menuDesc[izb], 5, s.getHeight()-1);
    help(s);
    
}

void unosIgraca(Screen& s, string *ig1, string *ig2)
{
    char msg[255];
    if (!ig1 || !ig2) return;
    s.clrScr();
    //s.setBright();
    s.setColor(clBrightYellow);
    s.cursorOn();
    sprintf(msg, "Igrac broj jedan [%s]: ", (const char *)(*ig1));
    s.outTextXY(msg, 5, 7);
    s.update();
    s.getText(ig1, 255);
    if (ig1->length() != 0) {
	s.setColor(clBrightYellow);
	for (int i = 0; i < s.getWidth(); i++)
	    s.outCharXY(' ', i, 7);
	sprintf(msg, "Igrac broj jedan [%s]", (const char *)(*ig1));
	s.outTextXY(msg, 5, 7);
    }
    s.setColor(clBrightYellow);
    sprintf(msg, "Igrac broj dva [%s]: ", (const char *)(*ig2));
    s.outTextXY(msg, 5, 9);
    s.update();
    s.getText(ig2, 255);
    s.cursorOff();
    s.update();
}
void onSat(void *param)
{
    Screen *s = (Screen *) param;
    struct tm *theTime = NULL;
    time_t tTime;

    if (!s) return;

    s->setColor(clBrightWhite);
    //s->setBright();
    tTime = time(NULL);
    theTime = localtime(&tTime);
    s->outTextXY(
        leadZero(s_itoa(theTime->tm_hour))
	+string(':')
	+leadZero(s_itoa(theTime->tm_min))
	+string(':')
	+leadZero(s_itoa(theTime->tm_sec)), 2, 20);
    s->update();
}
void onPobed(void *param)
{
    int i;
    ScreenAndPob *_sap = (ScreenAndPob *)param;

    if (!_sap) return;

    Screen *s = _sap->scr;
    string pob(string("NAJBOLJI JE ==--> ") + *(_sap->pob));

    for (i = 0; i < s->getWidth(); i++)
	s->outCharXY(' ', i, s->getHeight()-3);

    //s->setBright();
    s->setColor(clrs[clr++]);
    if (clr == maxclrs) clr = 0;
    if (pom>=s->getWidth()-pob.length()) {
        pom = s->getWidth()-pob.length()-1;
        znak = -1;
    }

    s->outTextXY(pob, pom, s->getHeight()-3);
    pom += znak;
    if (pom==0) znak = 1;
    else if (pom==s->getWidth()-pob.length()) znak = -1;
    s->update();
}
