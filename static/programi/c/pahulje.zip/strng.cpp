/*
 * $Id: strng.cc,v 1.8 2000/11/14 16:00:13 straxy Exp straxy $
 */

#include "strng.h" // defs ;)

string::string(const string& from) {
    len = from.len;
    content = new char[ (allocated=len + 1) ];
    strcpy( content, from.content );
}

string::string(const char *from) {
    if ( from == 0 )
        from = "";
    
    len = strlen( from );
    content = new char[ (allocated=len + 1) ];
    strcpy( content, from );
}

string::string(const char ch) {
    len = 1;
    content = new char[ (allocated=len + 1) ];
    content[0] = ch;
    content[1] = '\0';
}

int string::posOf(const char ch, const size_t st) const {
    for (size_t i = st; i < len; i++)
        if (content[i] == ch)
            return i;
    return -1;
}

string string::substr(size_t start, size_t end) const {
  string retval;
  if (start >= 0 && end < len)
    for (size_t i = start; i < end+1; i++)
      retval += content[i];
  return retval;
}

string string::toUpper(void) {
   string retval(*this);
   for (size_t i = 0; i < len; i++)
		retval.content[i] = toupper(retval[i]);
   return retval;
}

int string::contains(const string s) const {
    if (strstr(content, s.content))
        return 1;
    return 0;
}

int string::contains(const char *s) const {
    if (strstr(content, s))
        return 1;
    return 0;
}

string& string::operator=(const string& from) {
    if ( *this != from ) {
        if ( allocated < from.len+1 ) {
            if ( content ) delete content;
            len = from.len;
            content = new char[ (allocated=from.len + 1) ];
        }
	len = from.len;
        strcpy( content, from.content );
    }
    return *this;
}

string& string::operator=(const char *from) {
    size_t fromlen = strlen( from );
    if ( *this != from ) {
        if ( allocated < fromlen+1 ) {
            if ( content ) delete content;
            len = fromlen;
            content = new char[ (allocated=len + 1) ];
        }
	len = fromlen;
        strcpy( content, from );
    }
    return *this;
}

string& string::operator=(const char ch) {
    len = 1;
    if (allocated < 2) {
	if ( content ) delete content;
	content = new char[ (allocated=len + 1) ];
    }
    content[0] = ch;
    content[1] = '\0';
    return *this;
}

string& string::operator+=(const string& s1)
{
    if (allocated < len+s1.len+1) {
	char *newcont = new char[ (allocated=(len+=s1.len)+1) ];
	strcpy(newcont, content);
	strcat(newcont, s1.content);
	delete content;
	content = newcont;
    } else {
	len += s1.len;
	strcat(content, s1.content);
    }
    return *this;
}

string& string::operator+=(const char *s1) {
    if (allocated < len+strlen(s1)+1) {
	char *newcont = new char[ (allocated=(len+=strlen(s1))+1) ];
	strcpy(newcont, content);
	strcat(newcont, s1);
	delete content;
	content = newcont;
    } else {
	len += strlen(s1);
	strcat(content, s1);
    }
    return *this;
}

string& string::operator+=(const char ch) {
    if (allocated < len+1+1) {
	char *newcont = new char[ (allocated=(++len)+1) ];
	strcpy(newcont, content);
	newcont[len-1] = ch;
	newcont[len] = 0;
	delete content;
	content = newcont;
    } else {
	len++;
	content[len-1] = ch;
	content[len] = 0;
    }
    return *this;
}

string string::operator+(const string& s1) const {
    string retval("");
    retval = content;
    retval += s1;
    return retval;
}

string string::operator+(const char *s1) const {
    string retval("");
    retval = content;
    retval += s1;
    return retval;
}

string string::operator+(const char ch) const {
    string retval("");
    retval = content;
    retval += ch;
    return retval;
}

string& string::operator--() {
    return *this = substr(1, len-1);
}

string& string::operator--(int) {
    return *this = substr(0, len-2);
}

const char string::operator[](size_t pos) {
    if (pos >= 0 && pos < len)
        return content[pos];
    return content[len];
}

/*const char string::operator[](size_t pos) const {
    if (pos >= 0 && pos < len)
        return content[pos];
    return content[len];
}*/

int string::operator<(const string& comp) const {
    return strcmp(content, comp.content)<0;
}

int string::operator<(const char *comp) const {
    return strcmp(content, comp)<0;
}

int string::operator>(const string& comp) const {
    return strcmp(content, comp.content)>0;
}

int string::operator>(const char *comp) const {
    return strcmp(content, comp)>0;
}

int string::operator<=(const string& comp) const {
    return (strcmp(content, comp.content)<0)
        || ((len == comp.len) && !strcmp(content, comp.content));
}

int string::operator<=(const char *comp) const {
    return (strcmp(content, comp)<0)
        || ((len == strlen(comp)) && !strcmp(content, comp));
}

int string::operator>=(const string& comp) const {
    return (strcmp(content, comp.content)>0)
        || ((len == comp.len) && !strcmp(content, comp.content));
}

int string::operator>=(const char *comp) const {
    return (strcmp(content, comp)>0)
        || ((len == strlen(comp)) && !strcmp(content, comp));
}

int string::operator==(const string& comp) const {
    return ((len == comp.len) && !strcmp(content, comp.content));
}

int string::operator==(const char *comp) const {
    return ((len == strlen(comp)) && !strcmp(content, comp));
}

int string::operator!=(const string& comp) const {
    return !(*this == comp);
}

int string::operator!=(const char *comp) const {
    return !(*this == comp);
}

ostream& operator<<(ostream& o, const string& s) {
    if (!s.len)
        return o << "";
    return o << s.content;
}

istream& operator>>(istream& i, string& s) {
    char buf[2048];
    i.getline(buf, 2048);
    s = buf;

    return i;
}

string s_itoa(const int _i) {
  int i = _i;
  string res; int addPrefix = 0;
  if (i == 0) return res = "0";
  if (i < 0) {
    addPrefix = 1;
    i = -i;
  }
  while (i) {
    res = string('0' + (i % 10)) + res;
    i /= 10;
  }
  if (addPrefix) res = string("-") + res;
  return res;
}

int *s_atoi(string s) {
  static int res;
  int addPrefix = 0;
  size_t i;
  string temp;
  
  res = 0;
  if (s == "0") return &(res=0);
  for (i=0; i < s.length(); i++) {
    if (!isdigit(s[i]) && !strchr("+-", s[i])) return NULL;
    if (!isspace(s[i])) temp += s[i];
  }
  if (temp[(size_t)0] ==  '-')
    addPrefix = 1;
  for (i=0; i < temp.length()-1; i++) {
    res += 9-('9'-temp[i]);
    res *= 10;
  }
  res += 9-('9'-temp[i]);
  if (addPrefix) res = -res;
  return &res;
}

double s_pow(double a, double b) {
  double res;
  int divide = 0;
  
  res = 1.0;
  if (b == 0.0) return res;
  else if (b < 0.0) {
    divide = 1;
    b = -b;
  }
  
  while (b--)
    res *= a;
    
  if (divide) res = 1 / res;
  return res;
}

double *s_atod(string s) {
  static double res;
  double dtemp = 0.0;
  size_t i;
  int add_master_prefix = 0, add_prefix = 0, dt;
  string temp;
  
  res = 0.0;
  if (s == "0" || s == "0.0") return &(res = 0.0);
  for (i=0; i < s.length(); i++) {
    if (!isdigit(s[i]) && !strchr("+-.eE", s[i])) return NULL;
    if (!isspace(s[i])) temp += s[i];
  }
  i = 0;
  if (temp[i] == '-') {
    add_master_prefix = 1;
    i++;
  }
  while (i < temp.length() && !strchr(".eE", temp[i])) {
    if (!isdigit(temp[i])) return NULL;
    res += 9-('9'-temp[i]);
    if (i+1 != temp.length() && !strchr(".eE", temp[i+1])) res *= 10;
    i++;
  }
  
  if (i < temp.length()) {
    if (temp[i] == '.') {
      i++; dt=0;
      while (i < temp.length() && toupper(temp[i]) != 'E') {
        if (!isdigit(temp[i]) && toupper(temp[i]) != 'E') return NULL;
        dtemp += 9-('9'-temp[i]);
        if (i+1 < temp.length() && toupper(temp[i+1]) != 'E')
          dtemp *= 10;
        i++; dt++;
      }
      dtemp = dtemp * s_pow(10, -dt);
      res += dtemp;
    }
    dtemp = 0.0;
    if (toupper(temp[i]) == 'E') {
      i++;
      if (temp[i] == '-') add_prefix = 1;
      if (strchr("+-", temp[i])) i++;
      while (i < temp.length()) {
        dtemp += 9-('9'-temp[i]);
        if (i+1 != temp.length()) dtemp *= 10;
        i++;
      }
      if (add_prefix) dtemp = -dtemp;
      
      res *= s_pow(10, dtemp);
    }
  }
  if (add_master_prefix) res = -res;
  return &res;
}

string s_spaces(const int num)
{
    string ret;
    for (int i = 0; i < num; i++)
        ret += ' ';
    return ret;
}
