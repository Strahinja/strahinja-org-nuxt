/* -*- C++ -*- */
/******************************************/
/* P A H U L J E (c) 2001                 */
/*----------------------------------------*/
/*   Strahinja Radic,     ML 164/99       */
/*      <mr99164@alas.matf.bg.ac.yu>      */
/*   Milan Skaric,        MR 266/98       */
/*   Vladimir Raskovic,   MR 254/99       */
/*   Obrad Radosavljevic, ML 200/99       */
/******************************************/

#include "inifile.h"

IniFile::IniFile( Object *o, const char *fn )
    : Object( o, "IniFile" ), loaded( false ),
	modified( false ), data( )
{
    if (fn)
	fileName = fn;
}

IniFile::IniFile( Object *o, const char *ty, const char *fn )
    : Object( o, "IniFile" ), loaded( false ),
	modified( false ), data( )
{
    if (fn)
	fileName = fn;
    addType(ty);
}

/*void delIS(void *victim)
{
    if (victim)
	delete (IniStruct *)victim;
    victim = NULL;
}*/

void IniFile::load()
{
    string buf, newstr;
    size_t i;
    IniStruct *current = new IniStruct(), *newis = NULL;
    IniState state;
    bool wasValue = false, wasSecEnd = false, wasSection = false;

    if (!current) bad = true;

    loaded = false;

    if (bad) return;

    infile.open( fileName );
    if (infile) {

	state = NORMAL;

	while (!infile.eof()) {
	    infile >> buf;
	    for (i = 0; i < buf.length()+1; i++)
		switch(buf[i]) {
		    case '[':
				wasSecEnd = false;
				wasSection = true;
				current->section = "";
			if (state==ITEM || state==NORMAL)
			    state=SECTION;
			break;
		    case ']':
			if (state==SECTION) {
			    // add the sect
			    wasSecEnd=true; //state=ITEM;
			}
			break;
		    case '=':
			if (state==ITEM) {
			    state=VALUE; wasValue=true;
			}
			break;
		    case '\r': case '\n': case 0:
			if (state==VALUE || state==SECTION
			    || (state==COMMENT
			    	&& (current->item=="" || wasValue))
				) {
			    if (state==VALUE || state==COMMENT
					|| (state==SECTION && wasSecEnd)) {
				newis = new IniStruct();
                                if (!newis) bad = true;
                                if (bad) {
			            data.clearAll();
			            if (current) delete current;
				        return;
                                }
				newis->section = current->section;
					if (!(current->item.length()) && !wasSection) {
						current->section = "";
					}
				data.add( current );
				current = newis;
			    }
			    state=ITEM; wasValue=false; wasSection=false;
			} else if (state==ITEM && !(current->item.length())) {
				;
			} else {
			    data.clearAll();
			    if (current) delete current;
				return;
			}
			break;
		    case ';':
			if (state != COMMENT) {
			    state=COMMENT;
			    current->comment = ";";
				while (current->value[
					current->value.length()-1]==' ')
					current->value--;
			} else {
				current->comment += buf[i];
			}
			break;
		    default:
			if (state==NORMAL
				&& (isalpha(buf[i]) || isspace(buf[i]))
			) state=ITEM;
			switch(state) {
			    case SECTION:
					if (!wasSecEnd) {
				if (!(current->section.length())) {
					current->section = buf[i];
				} else {
					current->section += buf[i];
				}
					}
				break;
			    case ITEM:
               	if (isspace(buf[i]) && !(current->item.length())) {
					;
				} else {
					if (!(current->item.length())) {
						current->item = buf[i];
					} else {
						current->item += buf[i];
					}
                }
				break;
			    case VALUE:
				if (!(current->value.length())) {
					current->value = buf[i];
				} else {
					current->value += buf[i];
				}
				break;
			    case COMMENT:
				if (!(current->comment.length())) {
					current->comment = buf[i];
				} else {
					current->comment += buf[i];
				}
				break;
			    default:
				data.clearAll();
				if (current) delete current;
				return;
			}
			break;
		}
	}
	infile.close();
	loaded = true;
    }
}

void IniFile::save()
{
	size_t i;
	IniStruct *current = NULL;
	bool firstSection = true;

	if (!modified) return;

    outfile.open( fileName );
	for (i = 0; i < data.count(); i++) {
		current = data[i];
		if (current) {
			if (current->section.length()) {
				if (current->item.length()) {
					outfile
						<< current->item
						<< "="
						<< current->value;
					if (current->comment.length())
						outfile << " " << current->comment;
					outfile << endl;
				} else {
					if (!firstSection)
						outfile << endl;
					else firstSection = false;
					outfile
						<< "["
						<< current->section
						<< "]";
					if (current->comment.length())
						outfile << " " << current->comment;
					outfile << endl;
				}
			} else {
				if (current->comment.length())
					outfile << current->comment << endl;
			}
		}
	}
    outfile.close();
	modified = false;
}

bool matchesCriteria( void *is, void *crit )
{
    return (( is && crit
	      && ((IniStruct *)is)->section   && ((IniStruct *)is)->item
	      && ((IniStruct *)crit)->section && ((IniStruct *)crit)->item )
	    && ( ( ((IniStruct *)is)->section
			  == ((IniStruct *)crit)->section )
		 && ( ((IniStruct *)is)->item
			     == ((IniStruct *)crit)->item ) )
	) ? true : false;
}

const string IniFile::find( const string& section, const string& item )
{
    string def;
    if (data.count() > 0) {
	IniStruct *crit = new IniStruct( section, item, NULL, NULL );
        if (!crit) bad = true;
        if (bad) return def;
	IniStruct *found = data.firstThat( &matchesCriteria, crit );

	delete crit;

	if (found) return found->value;
    }
    return def;
}

void IniFile::add( const string& section, const string& item, const string& value )
{
    IniStruct *newis = new IniStruct( section, item, value, NULL );
    if (!newis) bad = true;
    if (bad) return;
    size_t i, j;
    IniStruct *newsect;
    IniStruct *found = data.firstThat( &matchesCriteria, newis );

	modified = true;

    if (found) {
       found->value = value;
       return;
    }

	for (i = 0; i < data.count(); i++)
		if (data[i]->section == section)
			for (j = i; j < data.count(); j++)
				if (data[j]->section != section) {
					data.addAt( newis, j );
					return;
				}
    newsect = new IniStruct( section, NULL, NULL, NULL );
    if (!newsect) bad = true;
    if (bad) return;
    found = data.firstThat( &matchesCriteria, newsect );

    if ( !found )
       data.add( newsect );
    data.add( newis );

    if (found) delete newsect;
}
