/* -*- C++ -*- */
/******************************************/
/* P A H U L J E (c) 2001                 */
/*----------------------------------------*/
/*   Strahinja Radic,     ML 164/99       */
/*      <mr99164@alas.matf.bg.ac.yu>      */
/*   Milan Skaric,        MR 266/98       */
/******************************************/

#include "timer.h"
#include "winctrl.h"
#include "app.h"

void tmcpy(Time& t, long sec, long msec)
{
    Time temp(sec, msec);
    t = temp;
}

Time::Time(Time& t)
{
    *this = t;

    normalize();
}

bool Time::operator==(const Time& t)
{
    return ( sec==t.sec && msec==t.msec );
}

bool Time::operator<(const Time& t)
{
    return ( sec < t.sec || sec == t.sec && msec < t.msec );
}

bool Time::operator>(const Time& t)
{
    return ( sec > t.sec || sec == t.sec && msec > t.msec );
}

bool Time::operator<=(const Time& t)
{
    return ( sec <= t.sec || sec == t.sec && msec <= t.msec );
}

bool Time::operator>=(const Time& t)
{
    return ( sec >= t.sec || sec == t.sec && msec >= t.msec );
}

Time& Time::operator=(const Time& t)
{
    sec  = t.sec;
    msec = t.msec;

    normalize();

    return *this;
}

Time Time::operator+(const Time& t)
{
    Time diff;

    diff.sec  = sec  + t.sec;
    diff.msec = msec + t.msec;

    diff.normalize();

    return diff;
}

/*Time Time::operator-()
{
    Time res;
    res.sec  = -sec;
    res.msec = -msec;
    res.normalize();

    return res;
}*/

Time Time::operator-(const Time& t)
{
    Time diff;

    diff.sec = sec - t.sec;
    if (msec - t.msec < 0) {
	diff.sec--;
	diff.msec = (1000 + msec - t.msec) % 1000;
    } else
	diff.msec = msec - t.msec;

    return diff;
}

Time& Time::operator+=(const Time& t)
{
    sec  += t.sec;
    msec += t.msec;

    normalize();

    return *this;
}

Time& Time::operator-=(const Time& t)
{
    sec -= t.sec;
    if (msec - t.msec < 0) {
	sec--;
	msec = (1000 + msec - t.msec) % 1000;
    } else
	msec = msec - t.msec;

    normalize();

    return *this;
}

void Time::getNow()
{
#if ISDOS
    struct time t;
    gettime(&t);
    sec  = time(NULL);
    msec = t.ti_hund * 10;
#else
    struct timeval tv;
    struct timezone tz;

    gettimeofday( &tv, &tz );
    sec  = tv.tv_sec;
    msec = (long int)(tv.tv_usec/1000);
#endif

    normalize();
}

// private

void Time::normalize()
{
    if (msec < 0) {
	sec -= (long int)(msec / 1000);
    } else {
	sec += (long int)(msec / 1000);
    }
    msec %= 1000;
}

//------- Timer -------

Timer::Timer( Object *o, callback_f f, const bool act, const bool c )
    : ELMember( o, "Timer" ), onTimer( f ), active( act ), continuous( c )
{
    application.registerELMember(this);
    return;
}

Timer::Timer( Object *o, const char *nm, callback_f f,
    const bool act, const bool c )
	 : ELMember( o, nm ), onTimer( f ), active( act ), continuous( c )
{
    application.registerELMember(this);
    addType("Timer");
    return;
}

Timer::~Timer()
{
    application.unregisterELMember(this);
}

void Timer::setTime(const Time& newt)
{
    endTime = newt;
}

const Time& Timer::getTime()
{
    return endTime;
}

void Timer::doInLoop()
{
    if (active) {
	if (period() > endTime) {
	    if (onTimer) (*onTimer)((void *)getOwner());
            if (continuous) reset();
            else stop();
	}
    }
}

void Timer::setActive(const bool onoff, const bool contin)
{
    if (onoff) {
        if (contin) cont();
        else        reset();
    } else stop();
}

void Timer::reset()
{
    stop();
    start();
}

void Timer::start()
{
    active = true;
    startTime.getNow();
    //startTime -= Time(1, 0);
}

void Timer::stop()
{
    active = false;
}

void Timer::cont()
{
    active = true;
}

Time Timer::period()
{
    Time now;

    if (active) {
	now.getNow();
	now -= startTime;
    }

    return now;
}
