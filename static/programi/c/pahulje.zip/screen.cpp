/* -*- C++ -*- */
/******************************************/
/* P A H U L J E (c) 2001                 */
/*----------------------------------------*/
/*   Strahinja Radic,     ML 164/99       */
/*      <mr99164@alas.matf.bg.ac.yu>      */
/*   Milan Skaric,        MR 266/98       */
/*   Vladimir Raskovic,   MR 254/99       */
/*   Obrad Radosavljevic, ML 200/99       */
/******************************************/

#include "screen.h"

#if !(ISDOS)
bool *pairs;
#endif

/*#include <stdio.h>
#define DBGOUT(s) do { fprintf(flog, s); } while(0)
#define DBGOUT1(s,p) do { fprintf(flog, s, p); } while(0)
#define DBGOUT2(s,p1,p2) do { fprintf(flog, s, p1,p2); } while(0)
#define DBGOUT3(s,p1,p2,p3) do { fprintf(flog, s, p1,p2,p3); } while(0)
FILE *flog = stderr;

void logit(const char *msg)
{
    DBGOUT1("%s\n",msg);
}*/

color_t ScreenColors[nColors]
    = {
	clBrightWhite, clBrightYellow, clBrightBlue, clBrightRed,
	clBrightGreen, clBrightMagenta, clBrightCyan, clBrightBlack,
	clWhite, clYellow, clBlue, clRed, clGreen, clMagenta, clCyan, clBlack,
	clTransp
    };

// public

Screen::Screen(Object *o, const bool db,
	       const coord_t w, const coord_t h )
    : Object( o, "Screen" ), doubleBuff( db ),
      skipTrans( true ), width( w ), height( h )
{
    __initScreen( db );
    //flog = fopen("scr.log", "w");
}

Screen::Screen(Object *o, const char *nm, const bool db,
	       const coord_t w, const coord_t h )
    : Object( o, nm ), doubleBuff( db ),
      skipTrans( true ), width( w ), height( h )
{
    __initScreen( db );
    //flog = fopen("scr.log", "w");
}

Screen::~Screen()
{
    if (map)   delete map;
    cursorOn();
#if ISDOS
    textcolor(clWhite);
    textbackground(clBlack);
    clrscr();
#else
    if (pairs) delete pairs;
    clear();
    endwin();
#endif
    //fclose(flog);
}

const bool Screen::gotoXY(const coord_t x, const coord_t y)
{
    if (outOfBounds(x,y)) return false;
    if (doubleBuff) {
	cx = x; cy = y;
    } else {
#if ISDOS
	gotoxy(x+1, y+1);
#else
    	move(y, x);
#endif
    }
    return true;
}

void Screen::setDoubleBuff(const bool onoff)
{
    if (onoff != doubleBuff) {  // Ako je isto, nema potrebe
	doubleBuff = onoff;     // za brljanjem
        ScreenField *newSF = new ScreenField[ width*height ];
        if (!newSF) bad = true;

	if (!bad) {
            if (map) delete map;
	    map = (onoff==true) ? newSF : NULL;
	    clrScr();
	    Refresh();
        }
    }
}

void Screen::setColor(const color_t fg, const color_t bg)
{
    currentFg = fg;
    currentBg = bg;
}

void Screen::setBlink(const bool onoff)
{
    if (onoff)
	currentFg |= clBlink;
    else
	currentFg &= ~clBlink;
}

void Screen::setBright(const bool onoff)
{
    if (onoff)
	currentFg |= clBright;
    else
	currentFg &= ~atBright;
}

void Screen::setReverse(const bool onoff)
{
    if (onoff)
	attrs |= atReverse;
    else
	attrs &= ~atReverse;
}

color_t Screen::randomColor(const unsigned int seed)
{
    if (ourSeed != seed) {
	ourSeed = seed;
#if ISDOS
	srand( ourSeed==0 ? time(NULL) : seed );
#else
	srandom( ourSeed==0 ? time(NULL) : seed );
#endif
    } else {
#if ISDOS
	srand( rand() % UINT_MAX );
#else
        srandom(random() % UINT_MAX);
#endif
    }

#if ISDOS
    switch (rand() % nColors) {
#else
    switch (random() % nColors) {
#endif
	case 0: return clBlack;   break;
	case 1: return clYellow;  break;
	case 2: return clBlue;    break;
	case 3: return clRed;     break;
	case 4: return clWhite;   break;
	case 5: return clGreen;   break;
	case 6: return clMagenta; break;
	case 7: return clCyan;    break;

	case 8:  return clBrightBlack;   break;
	case 9:  return clBrightYellow;  break;
	case 10: return clBrightBlue;    break;
	case 11: return clBrightRed;     break;
	case 12: return clBrightWhite;   break;
	case 13: return clBrightGreen;   break;
	case 14: return clBrightMagenta; break;
	case 15: return clBrightCyan;    break;
    }
    return clWhite;
}

void Screen::outChar(const chr_t ch)
{
    ScreenField *my_fld = NULL;
    if (bad) return;
    
    if (doubleBuff) {
	my_fld = &map[cy*width+cx];
	cx++;
	if (cx == width+1) {
	    cx--;
            return;
	}

	if (!skipTrans || skipTrans && ch != ' ') {
            if (currentFg & clTransp) {
                my_fld->fg = my_fld->bg | (currentFg & ~clTransp);
            } else {
                my_fld->fg = currentFg;
            }
	    if (currentBg & clTransp) {
		my_fld->bg = my_fld->bg | (currentBg & ~clTransp);
	    } else {
	        my_fld->bg = currentBg;
	    }
	    my_fld->attrs = attrs;
	    my_fld->data = ch;
            my_fld->modified = true;
	}
    } else {
	color_t cfg, cbg;

	cfg = currentFg;
	cbg = currentBg;

	if (cbg==clTransp) cbg = defBg;
	if (cfg==clTransp) cfg = defFg;
#if ISDOS
	color_t temp;

	if (attrs & atReverse) {
	    temp = cbg;
	    cbg = cfg;
	    cfg = temp;
	}

	if (attrs & atBlink)
	    cfg += BLINK;
	textcolor(cfg);
	textbackground(cbg);
	cprintf("%c", ch);
#else
	set_color(cfg, cbg, attrs);
	addch(ch);
#endif
	Refresh();
    }
}

void Screen::outCharXY(const chr_t ch, const coord_t x, const coord_t y)
{
    if (!gotoXY(x, y)) return;
    outChar( ch );
}

void Screen::outCharDirectXY(const chr_t c, const coord_t x, const coord_t y)
{
    ScreenField *my_fld = NULL;
    if (bad || outOfBounds(x,y)) return;

    if (doubleBuff) {
        if (!gotoXY(x,y)) return;
	my_fld = &map[cy*width+cx];
	cx++;
	if (cx == width+1) {
	    cx--;
            return;
	}
	my_fld->data  = c;
	my_fld->modified = true;
    } else
        outCharXY(c,x,y);
}

void Screen::outText(string text)
{
    size_t i;

    if (bad) return;

    if (doubleBuff)
	for (i = 0; i < text.length(); i++)
	    outChar( text[i] );
    else {
#if ISDOS
	color_t cfg, cbg;

	cfg = currentFg;
	cbg = currentBg;
	if (attrs & atReverse) {
	    cfg = currentBg;
	    cbg = currentFg;
	}

	if (attrs & atBlink)
	    cfg += BLINK;
	textcolor(cfg);
	textbackground(cbg);
	cprintf("%s", (const char *)text);
#else
	set_color(currentFg, currentBg, attrs);
	//DBGOUT3("outText(): %d,%d,%s\n",cx,cy,(const char *)text);
	addstr((const char *)text);
#endif
	Refresh();
    }
}

void Screen::outTextXY(string text, const coord_t x, const coord_t y)
{
    if (!gotoXY( x, y )) return;
    outText( text );
}

key_t Screen::getCh()
{
#if ISDOS
    char ch;

    if (kbhit()==0) return kbNoKey;

    ch = getch();
    if (!ch) {
       ch = getch();
       ch |= kbExt;
    }
    return ch;
#else
    return getch();
#endif
}

void Screen::outTextDirectXY(string text, const coord_t x, const coord_t y)
{
    if (bad || outOfBounds(x,y)) return;

    if (doubleBuff)
        for (size_t i = 0; i < text.length(); i++)
            outCharDirectXY(text[i],x,y);
    else
        outTextXY(text,x,y);
}

void Screen::clrScr()
{
    int i;

    if (bad) return;

    if (doubleBuff)
	for (i = 0; i < width * height; i++) {
	    initScreenField( &map[i] );
	    map[i].modified = true;
	}
    else {
#if ISDOS
	textcolor(LIGHTGRAY);
	textbackground(BLACK);
	clrscr();
#else
	clear();
#endif
	Refresh();
    }
}
 
coord_t Screen::whereX()
{
    if (doubleBuff == true) {
	return cx;
    } else {
#if ISDOS
	return wherex()-1;
#else
	coord_t x, y;
	getyx(stdscr, y, x);
	return x;
#endif
    }
}

coord_t Screen::whereY()
{
    if (doubleBuff == true) {
	return cy;
    } else {
#if ISDOS
	return wherey()-1;
#else
	coord_t x, y;
	getyx(stdscr, y, x);
	return y;
#endif
    }
}

void Screen::drawMatrix(const coord_t startx, const coord_t starty,
		const coord_t rows, const coord_t cols)
{
    int i, j;

    if (bad) return;

    if (!gotoXY(startx, starty)) return;
    outChar(chULCorner);
    for (j = 0; j < cols; j++) {
	outChar(chHLine);
	outChar(chHLine);
	outChar(chHLine);
	if (j != cols-1)
	    outChar(chUT);
    }
    outChar(chURCorner);
    
    for (i = 0; i < rows; i++) {
	for (j = 0; j < cols+1; j++) {
	    if (!gotoXY(startx+j*4, starty+2*i+1)) return;
	    outChar(chVLine);
	}

	if (!gotoXY(startx, starty+2*i+2)) return;
	outChar(chLT);
	for (j = 0; j < cols; j++) {
	    outChar(chHLine);
	    outChar(chHLine);
	    outChar(chHLine);
	    if (j != cols-1)
		outChar(chCross);
	}
	outChar(chRT);
    }
	
    if (!gotoXY(startx, starty+2*rows)) return;
    outChar(chDLCorner);
    for (j = 0; j < cols; j++) {
	outChar(chHLine);
	outChar(chHLine);
	outChar(chHLine);
	if (j != cols-1)
	    outChar(chDT);
    }
    outChar(chDRCorner);
}

void Screen::cursorOn()
{
#if ISDOS
    _setcursortype(_NORMALCURSOR);
#else
    curs_set(1);
#endif
}
 
void Screen::cursorOff()
{
#if ISDOS
    _setcursortype(_NOCURSOR);
#else
    curs_set(0);
#endif
}

void Screen::getText(string *s, const size_t n)
{
    key_t ch;

    if (bad) return;

    if (!s) return;
    (*s) = "";
    do {
	do {
	    ch = getCh();
	} while (ch == kbNoKey);
	if (ch == kbBackspace) {
	    if (s->length() != 0) {
		if (!gotoXY(whereX()-1, whereY())) return;
		outChar(' ');
		if (!gotoXY(whereX()-1, whereY())) return;
		update();
		(*s)--;
	    }
	} else if (isprint(ch)) {
	    (*s) += ch;
	    outChar(ch);
	    update();
	}
    } while (ch != kbEnter);
    (*s) = s->substr(0, min(n-1,s->length()-1));
}

void Screen::update()
{
    Refresh();
}

// private

void Screen::__initScreen( const bool db )
{
    int n, i;

#if ISDOS
    type = "conio.h";
#else
    type = "ncurses";
#endif
    
    doubleBuff = db;
    
#if ISDOS
    defBg = clBlack;
#else
    initscr(); cbreak(); noecho(); nonl(); leaveok(stdscr, TRUE);
    nodelay(stdscr, TRUE); keypad(stdscr, TRUE); timeout(0);
    if (has_colors()) {
	start_color();
	if (use_default_colors() == OK)
	    defBg = -1;
	else
	    defBg = clBlack;
    }
#endif
    cursorOff();
    attrs = 0;
    defFg = clWhite;
    
    currentFg = defFg;
    currentBg = defBg;
    
    n = width * height;
    map = new ScreenField[ n ];
    if (!map) bad = true;
    
    cx = 0; cy = 0;

    clrScr();
    
#if !(ISDOS)
    n = COLORS*COLORS;
    pairs = new bool[n];
    if (!pairs) bad = true;
    if (!bad)
        for (i = 0; i < n; i++)
    	    pairs[i] = false;
#endif
    
    ourSeed = time(NULL);
}

void Screen::Refresh()
{
    int i, j;
    ScreenField *current;

    if (bad) return;
    
    if (doubleBuff) {
	for (i = 0; i < height; i++)
	    for (j = 0; j < width; j++) {
		current = &map[i*width+j];
		if (current->modified) {
#if ISDOS
		    set_color(current->fg, current->bg, current->attrs);
                    if (!outOfBounds(j+1, i+1)) {
		        gotoxy(j+1, i+1);
			cprintf("%c", current->data);
                    }
#else
		    set_color(current->fg, current->bg, current->attrs);
		    mvaddch(i, j, current->data);
#endif
		    current->modified = false;
		}
	    }
    }
#if !(ISDOS)
    refresh();
#endif
}

void Screen::set_color(color_t fg, color_t bg, attrb_t att)
{
    if (fg & clBright) {
	fg &= ~clBright;
	att |= atBright;
    } else att &= ~atBright;
    if (bg & clBright) {
	bg &= ~clBright;
    }
    if (fg & clBlink) {
	fg &= ~clBlink;
	att |= atBlink;
    } else att &= ~atBlink;
    if (bg & clBlink) {
	bg &= ~clBlink;
    }
#if ISDOS
    color_t cfg, cbg;
    
    cfg = fg;
    cbg = bg;
    if (att & atReverse) {
	cfg = bg;
	cbg = fg;
    }
    
    if (att & atBlink)
	cfg += BLINK;
    textcolor(cfg);
    textbackground(cbg);
#else
    if (has_colors()) {
	int n = COLORS*fg+bg;
	if (!pairs[n]) {
	    init_pair(n, fg, bg);
	    //DBGOUT3("set_color(): init_pair(%d,%d,%d)\n",n,fg,bg);
	    pairs[n] = true;
	}
	attrset(COLOR_PAIR(n)+att);
    }
#endif
}

void Screen::initScreenField(ScreenField *sf)
{
    sf->data     = ' ';
    sf->attrs    = 0;
    sf->fg       = defFg;
    sf->bg       = defBg;
    sf->modified = false;
}
