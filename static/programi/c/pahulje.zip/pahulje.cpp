/* -*- C++ -*- */
/******************************************/
/* P A H U L J E (c) 2001                 */
/*----------------------------------------*/
/*   Strahinja Radic,     ML 164/99       */
/*      <mr99164@alas.matf.bg.ac.yu>      */
/*   Milan Skaric,        MR 266/98       */
/*   Vladimir Raskovic,   MR 254/99       */
/*   Obrad Radosavljevic, ML 200/99       */
/******************************************/

#include "pahulje.h"

const char *helpLine =
" k,j,h,l,Strelice=izbor; razmak,Enter=aktiviranje; Esc,q=izlaz   ";
const color_t helpColor = clWhite;

const color_t clIks = clBrightCyan;
const color_t clOks = clBrightYellow;

coord_t pom1=0, pom2=0;
signed char smer1=1,smer2=-1;

void help(Screen& s)
{
    s.setColor(helpColor);
    //s.setBright(false);
    s.setReverse(true);
    s.outTextXY(helpLine, 1, s.getHeight()-2);
    s.setReverse(false);
}

// public

Pahulje::Pahulje(Screen *s)
{
    sc = s;
    igrac1 = "Igrac1";
    igrac2 = "Igrac2";
    status = NERESENO;
}

void Pahulje::selectCell(XY pos, Player *p)
{
    size_t row=pos.y, col=pos.x;
    if (!tableFull()) {
	while (true) {
	    //row = findFree(col);
	    if (row != (size_t)-1) break;
	    col++; if (col == horzCells) col = 0;
	    if (col==pos.x) break;
	}
	selCell = XY(row, col);
	
	if (p && pos < XY(vertCells, horzCells)) {
	    map[selCell.y][selCell.x].p = NULL;
	    selCell = pos;
	    map[selCell.y][selCell.x].p = p;
	}
    }
}

void Pahulje::takeCell()
{
    selectCell(0,0);
}


void onPahuljeSat(void *param);
void onIgraci(void *param);

struct IgraciStruct {
    IgraciStruct(Screen *_sc, string& s1, string& s2, const Status& st)
	: sc(_sc), ig1(s1), ig2(s2), status(st) {;}
    Screen *sc;
    string& ig1;
    string& ig2;
    Status status;
};

const Status Pahulje::pocni()
{
    key_t ch;
    int i;
    bool prviNaRedu, poslednjiNaRedu, potezGotov;
    int column, prev, tempRow;
    int sx = 22, sy = 3;
    char buf[255];
    IgraciStruct igs(sc, igrac1, igrac2, NISTA);
    Timer sat( NULL, &onPahuljeSat );
    Timer igraci( NULL, &onIgraci );

    pom1 = 0;
    pom2 = sc->getHeight()-7;
    smer1 = 1;
    smer2 = -1;

    status = NISTA;
    for (i = 0; i < 8; i++)
	for (int j = 0; j < 8; j++)
	    tabla[i][j] = PRAZNO;
    sc->clrScr();
    help(*sc);
    sc->setColor( clBrightYellow );
    //sc->setBright();
    sc->drawMatrix(sx,sy,8,8);
    column = 0; prev = 0;
    prviNaRedu = true;
    poslednjiNaRedu = !prviNaRedu;
    potezGotov = false;

    sat.setTime(Time(1,0));
    igraci.setTime(Time(1,500));
    do {
	if (status==NISTA) {
	    drawPos(*sc, column, prev, sx, sy,
		    prviNaRedu);
	    if (prviNaRedu != poslednjiNaRedu) {
		sprintf(buf, "Na potezu je %s...",
			(const char *)(prviNaRedu ? igrac1 : igrac2));
		sc->gotoXY(0, sc->getHeight()-4);
		for (i = 0; i < sc->getWidth(); i++)
		    sc->outChar(' ');
		sc->setColor( clBrightYellow );
		//sc->setBright();
		sc->setBlink(false);
		sc->outTextXY(buf,
			      sc->getWidth()/2-strlen(buf)/2-1,
			      sc->getHeight()-4);
		poslednjiNaRedu = prviNaRedu;
	    }
	    sc->update();
	}
        do {
	     ch = sc->getCh();
             sat.doInLoop( sc );
	     igs.status = status;
             igraci.doInLoop( &igs );
        } while (ch == kbNoKey);
	if (status==NISTA){
	    switch (ch) {
		case kbUp: case 'k': case 'K':
		case kbRight: case 'l': case 'L':
		    prev = column;
		    do {
			column++;
			if (column == 8) column = 0;
		    } while (findFree(column) == -1);
		    break;
		case kbLeft: case 'h': case 'H':
		case kbDown: case 'j': case 'J':
		    prev = column;
		    do {
			column--;
			if (column == -1) column = 7;
		    } while (findFree(column) == -1);
		    break;
		case ' ': case kbEnter:
		    tempRow = findFree(column);
		    tabla[tempRow][column]
			= (prviNaRedu == true) ? IKS : OKS;
		    sc->gotoXY(sx+4*(column)+2, sy+2*(tempRow)+1);
		    //sc->setBright();
		    sc->setBlink(false);
		    sc->setColor( (prviNaRedu == true) ? clIks : clOks );
		    sc->outChar( (prviNaRedu == true) ? 'X' : 'O' );

		    potezGotov = true;
		    prviNaRedu = !prviNaRedu;
		    column = 0; prev = 0;
		    while (findFree(column) == -1) {
			column++;
			if (column == 8)
			    break;
		    }
		    prev = column;
		    ch = 0;
		    break;
                case 0://doInLoop()
                    break;
		default: break;
	    }
	    sc->update();
	    Status ishod = getStatus(sx, sy);
	    if (potezGotov) {
		if (ishod != NISTA) {
			gameOver(*sc, ishod);
			sc->update();
			igs.status = ishod;
                        do {
			    sat.doInLoop(sc);
			    igraci.doInLoop(&igs);
			    ch = sc->getCh();
                        } while (ch == kbNoKey);
                        sat.stop();
                        igraci.stop();
                        return ishod;
		}
		potezGotov = false;
	    }
	}
    } while (ch != 'q' && ch != 'Q' && ch != kbEsc);
    sat.stop();
    igraci.stop();
    return NISTA;
}

// private

void Pahulje::drawPos(Screen& s, const coord_t col, const coord_t pre,
		      const coord_t startx, const coord_t starty,
		      const bool iksOks)
{
    int i;
    if (pre != col) {
	i = findFree(pre);
	tabla[i][pre] = PRAZNO;
	s.gotoXY(startx+4*(pre)+2, starty+2*(i)+1);
	s.outChar( ' ' );
    }

    i = findFree(col);
    tabla[i][col] = (iksOks == true) ? T_IKS : T_OKS;
    s.gotoXY(startx+4*(col)+2, starty+2*(i)+1);
    s.setBlink();
    //s.setBright();
    s.setColor( (iksOks == true) ? clIks : clOks );
    s.outChar( (iksOks == true) ? 'X' : 'O' );
}

void Pahulje::gameOver(Screen& s, const Status stat)
{
    char buf[255];
    const char *msg = "NERESENO!";

    switch (stat) {
	case IGRAC1:
	    sprintf(buf, "Pobedio je %s! Bilo koji"
		    " taster za nastavak...", (const char *)igrac1);
	    break;
	case IGRAC2:
	    sprintf(buf, "Pobedio je %s! Bilo koji"
		    " taster za nastavak...", (const char *)igrac2);
	    break;
	default:
	    sprintf(buf, "%s", msg);
	    break;
    }

    s.setColor( clBrightYellow );
    //s.setBright();
    s.setBlink();

    for (int i = 0; i < s.getWidth(); i++)
       s.outCharXY(' ', i, s.getHeight()-4);

    s.outTextXY(buf,
		s.getWidth()/2-strlen(buf)/2-1,
		s.getHeight()-4);
    status = stat;
}

bool Pahulje::tableFull()
{
    int i;
    
    for (i = 0; i < 8; i++)
	if (findFree(i) != -1)
	    return false;
    return true;
}

int Pahulje::findFree(const coord_t col)
{
    int i;
    
    for (i=7; i > -1; i--)
	if (tabla[i][col] == PRAZNO
	    || tabla[i][col] == T_IKS
	    || tabla[i][col] == T_OKS)
	    break;
    return (i==-1) ? -1 : i;
}

Status Pahulje::getStatus(const coord_t startx, const coord_t starty)
{
#if ISMSFT
#define RETF \
                    switch (tabla[i][j]) { \
                        case IKS: return IGRAC1; break; \
                        case OKS: return IGRAC2; break; \
                        default: break; \
                    }
    int i, j, k;
#else
    int i, j, k;
#define RETF do{ switch (tabla[i][j]) { case IKS: return IGRAC1; break; case OKS: return IGRAC2; break; default: break; } }while(0)
#endif
		    //return (tabla[i][j]==IKS) ? IGRAC1 : IGRAC2;

    if (tableFull())
	return NERESENO;

    for (j=7; j > -1; j--)
	for (i=0; i < 8; i++) {
	    if (tabla[i][j] != PRAZNO) {
		for (k = 0; k < 4; k++) {
		    if (j+k > 7)
			break;
		    if (tabla[i][j+k] != tabla[i][j])
			break;
		}
		if (k==4) {
		    for (k=0; k < 4; k++) {
			sc->gotoXY(startx+4*(j+k)+2, starty+2*(i)+1);
			sc->setBlink();
			//sc->setBright();
			sc->setColor( (tabla[i][j]==IKS) ? clIks : clOks );
			sc->outChar( (tabla[i][j]==IKS) ? 'X' : 'O' );
		    }
		    RETF;
		}
		
		for (k = 0; k < 4; k++) {
		    if (i+k > 7)
			break;
		    if (tabla[i+k][j] != tabla[i][j])
			break;
		}
		if (k==4) {
		    for (k=0; k < 4; k++) {
			sc->gotoXY(startx+4*(j)+2, starty+2*(i+k)+1);
			sc->setBlink();
			//sc->setBright();
			sc->setColor( (tabla[i][j]==IKS) ? clIks : clOks );
			sc->outChar( (tabla[i][j]==IKS) ? 'X' : 'O' );
		    }
		    RETF;
		}
		
		for (k = 0; k < 4; k++) {
		    if ((i+k > 7) || (j+k > 7))
			break;
		    if (tabla[i+k][j+k] != tabla[i][j])
			break;
		}
		if (k==4) {
		    for (k=0; k < 4; k++) {
			sc->gotoXY(startx+4*(j+k)+2, starty+2*(i+k)+1);
			sc->setBlink();
			//sc->setBright();
			sc->setColor( (tabla[i][j]==IKS) ? clIks : clOks );
			sc->outChar( (tabla[i][j]==IKS) ? 'X' : 'O' );
		    }
		    RETF;
		}

		for (k = 0; k < 4; k++) {
		    if ((i+k > 7) || (j-k < 0))
			break;
		    if (tabla[i+k][j-k] != tabla[i][j])
			break;
		}
		if (k==4) {
		    for (k=0; k < 4; k++) {
			sc->gotoXY(startx+4*(j-k)+2, starty+2*(i+k)+1);
			sc->setBlink();
			//sc->setBright();
			sc->setColor( (tabla[i][j]==IKS) ? clIks : clOks );
			sc->outChar( (tabla[i][j]==IKS) ? 'X' : 'O' );
		    }
		    RETF;
		}
	    }
	}
    return NISTA;
}

const string leadZero(const string s)
{
   string ret = s;
   if (ret.length()==1) ret = string('0')+ret;
   return ret;
}

void onIgraci(void *param)
{
    size_t j;
    IgraciStruct *i = (IgraciStruct *) param;
    if (!i) return;
    if (!i->sc) return;

    switch (i->status) {
	case IGRAC1:
	    if (smer1==1 && pom1-smer1>=0
		&& pom1-smer1+2<i->sc->getHeight()) {
		i->sc->outCharXY(' ', i->ig1.length()/2, pom1-smer1+2);
		for (j = 0; j < i->ig1.length(); j++)
		    i->sc->outCharXY(' ', 1+j, pom1-smer1);
		i->sc->outCharXY(' ', i->sc->getWidth()-i->ig2.length()/2,
				 pom2-smer2+2);
		for (j = 0; j < i->ig2.length(); j++)
		    i->sc->outCharXY(' ', i->sc->getWidth()-i->ig2.length()+j,
				     pom2-smer2);
	    }
	    smer1 = -1;
	    smer2 = 1;
	    if (pom1 == (coord_t)-1) return;
	    break;
	case IGRAC2:
	    if (smer2==1 && pom2-smer2>=0
		&& pom2-smer2+2<i->sc->getHeight()) {
		i->sc->outCharXY(' ', i->ig1.length()/2, pom1-smer1+2);
		for (j = 0; j < i->ig1.length(); j++)
		    i->sc->outCharXY(' ', 1+j, pom1-smer1);
		i->sc->outCharXY(' ', i->sc->getWidth()-i->ig2.length()/2,
				 pom2-smer2+2);
		for (j = 0; j < i->ig2.length(); j++)
		    i->sc->outCharXY(' ', i->sc->getWidth()-i->ig2.length()+j,
				     pom2-smer2);
	    }
	    smer1 = 1;
	    smer2 = -1;
	    if (pom2 == (coord_t)-1) return;
	    break;
	case NERESENO:
	    if (pom1 == i->sc->getHeight()/2+smer1) smer1 = 0;
	    if (pom2 == i->sc->getHeight()/2+smer2) smer2 = 0;
	    break;
	default: ;
    }

    if (smer1) {
	while ((signed char)(pom1-smer1)<0) pom1++;
	while (pom1-smer1>i->sc->getHeight()-6) pom1--;
	//i->sc->setBright();
	i->sc->setBlink(false);
	i->sc->setColor(clIks);
	i->sc->outCharXY(' ', i->ig1.length()/2, pom1-smer1+2);
	for (j = 0; j < i->ig1.length(); j++)
	    i->sc->outCharXY(' ', 1+j, pom1-smer1);
	i->sc->outCharXY('X', i->ig1.length()/2, pom1+2);
	i->sc->outTextXY(i->ig1, 1, pom1);
	pom1 += smer1;
	if (pom1==(coord_t)-1) {
	    smer1 = 1;
	    pom1++;
	} else if (pom1==i->sc->getHeight()-6) {
	    smer1 = -1;
	    pom1--;
	}
    }
    if (smer2) {
	while ((signed char)(pom2-smer2)<0) pom2++;
	while (pom2-smer2>i->sc->getHeight()-6) pom2--;
	i->sc->setColor(clOks);
	i->sc->outCharXY(' ', i->sc->getWidth()-i->ig2.length()/2-1,
			 pom2-smer2+2);
	for (j = 0; j < i->ig2.length(); j++)
	    i->sc->outCharXY(' ', i->sc->getWidth()-i->ig2.length()+j-1,
			     pom2-smer2);
	i->sc->outCharXY('O',
			 i->sc->getWidth()-i->ig2.length()/2-1, pom2+2);
	i->sc->outTextXY(i->ig2,
			 i->sc->getWidth()-i->ig2.length()-1, pom2);
	pom2 += smer2;
	if (pom2==(coord_t)-1) {
	    smer2 = 1;
	    pom2++;
	} else if (pom2==i->sc->getHeight()-6) {
	    smer2 = -1;
	    pom2--;
	}
    }
    i->sc->update();
}

void onPahuljeSat(void *param)
{
    Screen *s = (Screen *) param;
    time_t tTime;
    struct tm *theTime = NULL;
    tTime = time(NULL);
    theTime = localtime(&tTime);
    string msg = leadZero(s_itoa(theTime->tm_hour))
        +string(':')
	+leadZero(s_itoa(theTime->tm_min))
	+string(':')
	+leadZero(s_itoa(theTime->tm_sec));

    if (!s) return;

    tTime = time(NULL);
    theTime = localtime(&tTime);
    //s->setBright();
    s->setBlink(false);
    s->setColor(clBrightWhite);
    s->outTextXY(msg, s->getWidth()/2-msg.length()/2, s->getHeight()-1);
    s->update();
}
