#pragma warn -inl
#include "rec.h"

Application::Application()
   {
       desktop = new Window();
       for (int i = 0; i < 100; i++)
           children[i] = new Window();
   }

void Application::foo()
{
;
}

void Application::run()
{
;
}

void Application::draw()
{
       for (int i = 0; i < 100; i++) {
           children[i]->foo();
}

void Window::foo()
{
   application->run();
}

Application *application = new Application();

int main()
{
    return 0;
}
