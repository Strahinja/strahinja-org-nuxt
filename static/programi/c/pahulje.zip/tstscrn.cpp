//#include "screen.h"
//#include "strng.h"
#include <iostream.h>

struct Nova {
    int i;
    char a;
};

Nova *alociraj(Nova *izm, int i, char a)
{
    Nova *n = new Nova;
    n->i = i;
    n->a = a;
    izm->i += i;
    izm->a += a-'A';
    return n;
}

main()
{
    Nova niz[3];
    niz[0] = *alociraj(&niz[0], 2,'B');
    niz[1] = *alociraj(&niz[0], 1,'A');
    niz[2] = *alociraj(&niz[0], 0,'C');
    cout << niz[0].i << ", " << niz[0].a << endl;
    cout << niz[1].i << ", " << niz[1].a << endl;
    cout << niz[2].i << ", " << niz[2].a << endl;
/*   Screen s(NULL);

   //logit("clrScr()");

   s.setSkipTrans(false);
   s.setColor(clBrightWhite, clRed);
   for (int k = 0; k < s.getHeight(); k++)
       for (int l = 0; l < s.getWidth(); l++)
           s.outCharXY(' ', l, k);
   s.update();

   s.setColor(clTransp|clBright|clBlink, clBrightWhite);
   //s.setBlink(true);
   for (int j = 0; j < s.getHeight(); j++) {
      //for (int i = 0; i < s.getWidth(); i++) {
      //   s.outCharXY(' ', i, j);
      //}
      s.outTextXY(string("Vrsta ")+s_itoa(j), 0, j);
   }

   s.update();
   char ch;
   //logit("getCh()");
   do {
      ch = s.getCh();
   } while (ch == kbNoKey);
   //logit("clrScr()");
   s.clrScr();
   s.update();*/

   return 0;
}
