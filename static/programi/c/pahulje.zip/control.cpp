#include "winctrl.h"

WinControl::~WinControl()
{
	 DynArray<WinControl> *ch;
	 if (getOwner() && getOwner()->isA("WinControl")) {
	     ch=((WinControl *)getOwner())->getChild();
	     ch->remove(this);
         }
	 if (isVisible() && getOwner() && getOwner()->isA("WinControl"))
		  ((WinControl *)getOwner())->invalidate();
}

void WinControl::show()
{
	 setVisible();
	 invalidate();
}

void WinControl::hide()
{
	 setVisible(false);
	 if (isFocused())
			focusNext(true);
}

const bool WinControl::isShowing() const
{
	 return getOwner() && getOwner()->isA("WinControl") &&
	     ((WinControl *)getOwner())->isShowing() && isVisible();
}

const bool WinControl::setFocus()
{
	 if (isShowing() && isEnabled() && options.canFocus) {
		  state.focused = true;
		  if (getOwner() && getOwner()->isA("WinControl"))
				((WinControl *)getOwner())->setFocus();
		  show();
	 } else {
		  return false;
	 }
	 return true;
}

void WinControl::messageKeyPress(const key_t ch)
{
	 if (ch==kbTab) {
		  focusNext(false);
	 } else if (ch==kbShiftTab) {
		  focusPrev(false);
	 } else if (ch=='`') {
		  focusNext(true);
	 } else if (ch=='~') {
		  focusPrev(true);
	 } else if (ch==kbEsc) {
		  if (focusedChild) {
				focusedChild->state.focused = false;
				focusedChild  = NULL;
		  }
	 } else {
             key_t _ch = ch;
	     if (onKeyPress)
	         (*onKeyPress)(&_ch);
	     else
	         defaultOnKeyPress();
	 }
}

void WinControl::draw()
{
	 if (isShowing()) {
		  drawBack();
		  drawSurf();
		  drawChildren();
	 }
}

void WinControl::drawChildren()
{
	 if (isShowing())
		  for (int i = 0; i < child.count(); i++)
				if (child[i]->isVisible()) {
					 child[i]->draw();
				}
}

void WinControl::focusNext(const bool toParent)
{
	 if (toParent) {
		  if (getOwner() && getOwner()->isA("WinControl"))
				((WinControl *)getOwner())->focusNext(false);
	 } else {
		  if (focusedChild) {
				size_t fci = child.posOf(focusedChild);
                                int k;
				for (int i = 0; i < child.count(); i++) {
					 k = (fci+i > child.count())
						? fci+i-child.count() : i;
					 if (child[k]->setFocus())
						  break;
				}
				if (i==child.count())
					 focusNext(true);
		  }
	 }
}

void WinControl::focusPrev(const bool toParent)
{
	 if (toParent) {
		  if (getOwner() && getOwner()->isA("WinControl"))
				((WinControl *)getOwner())->focusPrev(false);
	 } else {
		  if (focusedChild) {
				size_t fci = child.posOf(focusedChild);
                                int k;
				for (int i = child.count()-1; i != -1; i--) {
					 k = (fci+i > child.count())
						? fci+i-child.count() : i;
					 if (child[k]->setFocus())
						  break;
				}
				if (i==-1)
					 focusPrev(true);
		  }
	 }
}

void WinControl::invalidate()
{
	 application.setDrawFrom(this);
}

void WinControl::addComponent(WinControl* comp)
{
	 if (!comp) return;
	 comp->owner = this;
	 comp->hLevel = hLevel + 1;
	 child.add(comp);
	 if (comp->isVisible()) invalidate();
}

size_t WinControl::componentIndex()
{
	 DynArray<WinControl> *ch;
	 if (owner && (ch=owner->getChild()))
		  return ch->posOf(this);
	 return INT_MAX;
}
