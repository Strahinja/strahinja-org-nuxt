#!/usr/bin/perl -w

require 5.004;

use Tk;
use Tk::Dialog;

$w = MainWindow->new;
$w->title("Zdravo, svete!");

$buttons = $w->Frame;
$buttons->pack(qw/-side bottom -fill x -pady 2m/);
$gotovo = $buttons->Button(
   -text    => "Gotovo",
   -command =>
   sub {
      my ($izadji) = $w->Dialog(
         -bitmap  => 'question',
         -buttons => ['Da', 'Ne'],
         -title   => 'Potvrda',
         -text => 'Da li ste SASVIM sigurni da hocete' .
            ' izlaz iz ovog predivnog programa?',
      );
      $izadji->Show =~ /Da/ && $w->destroy;
   },
);
$oprog = $buttons->Button(
   -text    => "O Programu",
   -command =>
   sub {
      if (not Exists $o) {
         $o = $w->Toplevel;
         $o->geometry('+'.($w->x+$w->width+20).'+'.($w->y+20));
   
         if ($w->depth  > 1) {
            @bold   = (-background => '#43ce80',
               qw/-relief raised -borderwidth 1/);
            @normal = (-background => undef, qw/-relief flat/);
         } else {
            @bold   = (qw/-foreground white -background black/);
            @normal = (-foreground => undef, -background => undef);
         }

         $o->title("O Programu");

         $frame = $o->Frame(qw/-borderwidth 0/);
         $frame->pack(qw/-side top -expand yes -fill y/);

         my($t) = $frame->Scrolled('Text',
            -width  => 37,
            -height => 18,
         );
         $t->pack;
         $t->insert('0.0',
            "Ovo je program hello\n".
            "Copyright (c) 2001\n".
            "Strahinja Radic.");
         $t->insert('end',"\n\n");
         $t->insert('end',
            "Ovaj program je pod GNU licencom.".
            " Za detalje o GNU licenci posetite".
            " sledeci URL:", 'txt');
         $t->tag('configure', 'txt', (
            -justify  => 'center',
            -lmargin1 => '12m',
            -lmargin2 => '6m',
            -rmargin  => '10m',
            )
         );
         $t->insert('end', "\n\n");
         $t->insert('end', "http://www.gnu.org/", 'gnuorg');
         $t->tag('configure', 'gnuorg', qw/-justify center/);
         $t->tag('bind', 'gnuorg', '<Any-Enter>' =>
            sub { $t->tag('configure', 'gnuorg', @bold); });
         $t->tag('bind', 'gnuorg', '<Any-Leave>' =>
            sub { $t->tag('configure', 'gnuorg', @normal); });
         $t->tag('bind', 'gnuorg', '<1>' =>
            sub { system 'start http://www.gnu.org/'; });

         $t->insert('end', "\n\n");
         $t->insert('end', "Mozete posetiti i".
            " moju prezentaciju na adresi:", 'txt2');
         $t->tag('configure', 'txt2', (
            -justify  => 'center',
            -lmargin1 => '12m',
            -lmargin2 => '6m',
            -rmargin  => '10m',
            )
         );
         $t->insert('end', "\n\n");
         $t->insert('end', "http://alas.matf.bg.ac.yu/~mr99164/",
            'hp');
         $t->tag('configure', 'hp', qw/-justify center/);
         $t->tag('bind', 'hp', '<Any-Enter>' =>
            sub { $t->tag('configure', 'hp', @bold); });
         $t->tag('bind', 'hp', '<Any-Leave>' =>
            sub { $t->tag('configure', 'hp', @normal); });
         $t->tag('bind', 'hp', '<1>' =>
            sub { system "start".
               " http://alas.matf.bg.ac.yu/~mr99164/"; });
         $t->mark('set', 'insert', '0.0');
         $t->pack(qw/-expand 0/);

         $dugmad = $o->Frame;
         $dugmad->pack(qw/-side bottom -expand yes -fill y/);

         $ok = $dugmad->Button(
            -text    => "U redu",
            -command => sub { $o->destroy; },
         );
         $ok->pack(qw/-expand 1/);
      }
   },
);
$gotovo->pack(qw/-side left -expand 1/);
$oprog->pack(qw/-side left -expand 1/);

$frame = $w->Frame(qw/-borderwidth 5/);
$frame->pack(qw/-side top -expand yes -fill y/);

$list = $frame->Scrolled('Listbox',
   -setgrid    => 1,
   -width      => 25,
   -height     => 16,
   -scrollbars => 'e',
);
$list->pack(qw/-side left -fill both/);
$list->insert(0, qw/Ovo je lista/, '', 'Mogu se unositi',
   'i odvojene', 'stavke.', '', 'Stavke se unose',
   'na dva nacina:', 'koristeci Perl-ov', 'operator qw//',
   'ili jedna po jedna,', 'razdvojene zapetama',
   'i okruzene apostrofima.'
);

MainLoop;
