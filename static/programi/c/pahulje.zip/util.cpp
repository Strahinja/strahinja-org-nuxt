#include "util.h"

#if ISBLND
const bool true  = 1;
const bool false = 0;
#endif

const string leadZero(const string s)
{
   string ret = s;
   if (ret.length()==1) ret = string('0')+ret;
   return ret;
}
