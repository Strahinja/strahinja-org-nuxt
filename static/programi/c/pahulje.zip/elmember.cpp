/* -*- C++ -*- */
/******************************************/
/* P A H U L J E (c) 2001                 */
/*----------------------------------------*/
/*   Strahinja Radic,     ML 164/99       */
/*      <mr99164@alas.matf.bg.ac.yu>      */
/*   Milan Skaric,        MR 266/98       */
/*   Vladimir Raskovic,   MR 254/99       */
/*   Obrad Radosavljevic, ML 200/99       */
/******************************************/

#include "elmember.h"

ELMember::ELMember( Object *o )
    : Object( o, "ELMember" )
{
}

ELMember::ELMember( Object *o, const char *nm )
    : Object( o, nm )
{
}
