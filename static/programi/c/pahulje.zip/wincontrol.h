/* -*- C++ -*- */
/******************************************/
/* P A H U L J E (c) 2001                 */
/*----------------------------------------*/
/*   Strahinja Radic,     ML 164/99       */
/*      <mr99164@alas.matf.bg.ac.yu>      */
/*   Milan Skaric,        MR 266/98       */
/*   Vladimir Raskovic,   MR 254/99       */
/*   Obrad Radosavljevic, ML 200/99       */
/******************************************/

#ifndef __wincontrol_h
#define __wincontrol_h

#include "object.h"

class WinControl : public Object {
public:
    WinControl( Object *o );
    WinControl( Object *o, const char *nm );
    ~WinControl();
    inline const int getTop() { return top; }
    inline const int getLeft() { return left; }
    inline const int getWidth() { return width; }
    inline const int getHeight() { return height; }
    inline void setTop(const int nt)    { top    = nt; }
    inline void setLeft(const int nl)   { left   = nl; }
    inline void setWidth(const int nw)  { width  = nw; }
    inline void setHeight(const int nh) { height = nh; }
    inline void setPosition(const int t, const int l,
			    const int w, const int h)
	{
	    setTop(t); setLeft(l); setWidth(w); setHeight(h);
	}
    virtual void show();
    virtual void hide();
    inline void setVisible(const bool nv) { visible = nv; }
    void setShowing( const Object *sender, const bool onoff );
    void addComponent( WinControl *obj );
private:
    int top, left, width, height;
    bool visible, showing;
    WinControl *parent;
};

#endif
