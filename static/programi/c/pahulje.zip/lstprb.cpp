#include <stdio.h>
#include "dynarray.h"

typedef DynArray<int> intarr;

const size_t N = 100;

bool equalsNumber(void *curr, void *num);
Compare rastuci(void *e1, void *e2, void *p);

main()
{
    intarr il;
    size_t i;
	int aNum;
    int *ptrlist = new int[N];

    printf("Prikazujem listu...\n");
    for (i = 0; i < il.count(); i++)
	printf("Na poziciji %d je broj %d\n",
	       i, *il[i]);
    printf("Gotovo! (alloc=%d,count=%d)\n", il.numAllocated(),
	   il.count());

    for (i = 0; i < N; i++)
	ptrlist[i] = i;

    printf("il.add()...\n");    
    for (i = 0; i < N; i++)
	il.add( &ptrlist[i] );

	printf("il.sort()...\n");
	il.sort(&rastuci, NULL);

    printf("Prikazujem listu...\n");
    for (i = 0; i < il.count(); i++)
	printf("Na poziciji %d je broj %d\n",
	       i, *il[i]);
    printf("Gotovo! (alloc=%d,count=%d)\n", il.numAllocated(),
	   il.count());
	printf("Bilo koji taster...");
	char ch;
	scanf("%c", &ch);

    printf("il.swap()\n");
    il.swap( il.firstThat( &equalsNumber, &(aNum=2) ),
	     il[ il.count()-1 ] );

    printf("il.swap()\n");
    il.swap( il.posOf( il.firstThat( &equalsNumber, &(aNum=4) ) ),
	     il.count()-2 );

    printf("Prikazujem listu...\n");
    for (i = 0; i < il.count(); i++)
	printf("Na poziciji %d je broj %d\n",
	       i, *il[i]);
    printf("Gotovo! (alloc=%d,count=%d)\n", il.numAllocated(),
	   il.count());
    
    printf("il.remove(1)\n");
    il.remove( 1 );
    
    aNum = 3;
    int *poseban = il.firstThat(&equalsNumber, &aNum);
    printf("li.remove(poseban==&(%d))\n", *poseban);
    il.remove( poseban );
    delete poseban;

    printf("il.sendToStart(il[4])\n");
    il.sendToStart(il[4]);

    printf("il.sendToStart(il[0])\n");
    il.sendToStart(il[0]);
    
    printf("Prikazujem listu...\n");
    for (i = 0; i < il.count(); i++)
	printf("Na poziciji %d je broj %d\n",
	       i, (il[i] != NULL) ? *il[i] : -1);
    printf("Gotovo! (alloc=%d,count=%d)\n", il.numAllocated(),
	   il.count());

    printf("il.clearAll()\n");
    /*int *victim;
    for (i = 0; i < il.count(); i++) {
        victim = il[i];
        il.remove(i);
        delete victim;
    }*/
    il.clearAll();
    
    printf("Prikazujem listu...\n");
    for (i = 0; i < il.count(); i++)
	printf("Na poziciji %d je broj %d\n",
	       i, (il[i] != NULL) ? *il[i] : -1);
    printf("Gotovo! (alloc=%d,count=%d)\n", il.numAllocated(),
	   il.count());

    aNum = 6;
    printf("il.add(6)\n");
    il.add( &aNum );
    
    printf("Prikazujem listu...\n");
    for (i = 0; i < il.count(); i++)
	printf("Na poziciji %d je broj %d\n",
	       i, (il[i] != NULL) ? *il[i] : -1);
    printf("Gotovo! (alloc=%d,count=%d)\n", il.numAllocated(),
	   il.count());

    return 0;

}

bool equalsNumber(void *curr, void *num)
{
    return (curr && num && *(int *)curr==*(int *)num) ? true : false;
}

Compare rastuci(void *e1, void *e2, void *p)
{
	return ((*(int *)e1)>(*(int *)e2)) ? LT : GT;
}
