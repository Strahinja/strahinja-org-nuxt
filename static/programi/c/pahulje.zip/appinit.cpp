/* -*- C++ -*- */
/******************************************/
/* P A H U L J E (c) 2001                 */
/*----------------------------------------*/
/*   Strahinja Radic,     ML 164/99       */
/*      <mr99164@alas.matf.bg.ac.yu>      */
/*   Milan Skaric,        MR 266/98       */
/*   Vladimir Raskovic,   MR 254/99       */
/*   Obrad Radosavljevic, ML 200/99       */
/******************************************/

#include "appinit.h"

void AppInit::setDrawFrom(WinControl *ctrl)
{
    if (!ctrl) return;

    if (!drawFrom)
	drawFrom = ctrl;

    if (ctrl->getHLevel() < drawFrom->getHLevel())
        drawFrom = ctrl;
}

void AppInit::registerELMember( ELMember *elm, void *param )
{
    ELMInfo *e;
    if (!elm) return;
    e = new ELMInfo;
    e->member = elm;
    e->param = param;
    elmembers.add(e);
}
