/* -*- C++ -*- */
/******************************************/
/* P A H U L J E (c) 2001                 */
/*----------------------------------------*/
/*   Strahinja Radic,     ML 164/99       */
/*      <mr99164@alas.matf.bg.ac.yu>      */
/*   Milan Skaric,        MR 266/98       */
/*   Vladimir Raskovic,   MR 254/99       */
/*   Obrad Radosavljevic, ML 200/99       */
/******************************************/

#include "elmember.h"

ELMember::ELMember( Object *o )
    : Object( o, "ELMember" )
{
}

ELMember::ELMember( Object *o, const char *nm )
    : Object( o, nm )
{
}

ELMember::~ELMember()
{
    freeMe();
}

void ELMember::doInLoop(void *arg)
{
    return;
}
/* -*- C++ -*- */
/******************************************/
/* P A H U L J E (c) 2001                 */
/*----------------------------------------*/
/*   Strahinja Radic,     ML 164/99       */
/*      <mr99164@alas.matf.bg.ac.yu>      */
/*   Milan Skaric,        MR 266/98       */
/*   Vladimir Raskovic,   MR 254/99       */
/*   Obrad Radosavljevic, ML 200/99       */
/******************************************/

#ifndef __dynarray_h
#define __dynarray_h

#include <string.h>
#include "object.h"

#if ISDOS
#define DO_PT_TYPEDEF typedef T *PT
#define _PT(arg) PT arg
#define __PT PT
#else // gcc
#define DO_PT_TYPEDEF
#define _PT(arg) T *arg
#define __PT (T *)
#endif

template <class T>
    class DynArray : public Object {
    public:
	DynArray( Object *o, const int dlt = 10 )
	    : Object( o, "DynArray" ), delta( dlt ), data( NULL ),
	      numItems( 0 ), allocated( 0 ), compacted( true ) { ; }
	DynArray( Object *o, const char *nm, const int dlt = 10 )
	    : Object( o, nm ), delta( dlt ), data( NULL ),
	      numItems( 0 ), allocated( 0 ), compacted( true ) { ; }
	~DynArray() { ; }
	virtual void freeMe()
	    {
		if (data) delete data;
		data = NULL;
		numItems = allocated = 0;
		compacted = true;
	    }
	inline const int count() { return numItems; }
	inline const bool isCompacted() { return compacted; }
	inline const int numAllocated() { return allocated; }
	inline const bool outOfBounds( const int i )
	    { return ( (i < 0) || (i > numItems) ) ? true : false; }
	T *add( T *ptr )
	    {
		DO_PT_TYPEDEF;
		compact();
		
		if (!data) {
		    data = new __PT[(allocated=delta)];
		    for (int i = 0; i < allocated; i++)
			data[i] = NULL;
		} else if (numItems==allocated) {
		    grow();
		}
		
		data[numItems] = ptr;    
		numItems++;

		return data[numItems-1];
	    }
	void remove( T *ptr )
	    {
		int pos = posOf( ptr );

		remove( pos );
	    }
	void remove( const int i )
	    {
		if ( !outOfBounds( i ) ) {
		    compacted = false;
		    data[ i ] = NULL;
		    numItems--;
		}
	    }
	T *itemAt( const int i )
	    {
		compact();

		if ( !outOfBounds( i ) )
		    return data[ i ];

		return NULL;
	    }
	const int posOf( T *ptr )
	    {
		int i;
		compact();

		for (i = 0; i < numItems; i++)
		    if (data[i]==ptr)
			return i;

		return -1;
	    }
	void compact()
	    {
		DO_PT_TYPEDEF;
		_PT(*newdata); _PT(*temp);
		int i, j, newalloc;

		if (isCompacted()) return;

		newalloc = (((int)numItems/delta)+1)*delta;
		newdata = new __PT[ newalloc ];

		for (i = 0; i < newalloc; i++)
		    newdata[i] = NULL;

		j = 0;
		for (i = 0; i < allocated; i++)
		    if (data[i])
			newdata[j++] = data[i];

		temp = data;
		data = newdata;
		
		allocated = newalloc;
		numItems = j;
		
		compacted = true;
		
		delete temp;
	    }
	void grow()
	    {
		DO_PT_TYPEDEF;
		_PT(*newdata); _PT(*temp);
		int i;
		
		compact();
		if (isCompacted()) {
		    newdata = new __PT[( allocated += delta )];
		    for (i = 0; i < allocated; i++)
			newdata[i] = NULL;
		    for (i = 0; i < numItems; i++)
			newdata[i] = data[i];
		    
		    temp = data;
		    data = newdata;
		    
		    delete temp;
		}
	    }
	void sort( compare_f f, void *param )
	    {
		;
	    }
	void swap( const int i1, const int i2 )
	    {
		T *temp;

		compact();

		if ( outOfBounds(i1) || outOfBounds(i2) )
		    return;

		temp       = data[ i2 ];
		data[ i2 ] = data[ i1 ];
		data[ i1 ] = temp;
	    }
	void swap( T *t1, T *t2 )
	    {
		int i1, i2;

		compact();
		
		if (!t1 || !t2)
		    return;

		i1 = posOf( t1 );
		i2 = posOf( t2 );

		swap( i1, i2 );
	    }
	T *operator[](const int i)
	    {
		compact();

		if ( !outOfBounds( i ) )
		    return itemAt( i );

		return NULL;
	    }
	T *firstThat( criteria_f f, void *arg )
	    {
		int i;

		if (!f) return NULL;

		compact();
		
		for (i = 0; i < numItems; i++)
		    if ( f(data[i], arg) )
			return data[i];

		return NULL;
	    }
	void forEach( callback_f f )
	    {
		int i;

		if (!f) return;

		compact();

		for (i = 0; i < numItems; i++)
		    f( data[i] );
	    }
    private:
	int delta;
	T **data;
	int numItems, allocated;
	bool compacted;
    };

#endif
/* -*- C++ -*- */
/******************************************/
/* P A H U L J E (c) 2001                 */
/*----------------------------------------*/
/*   Strahinja Radic,     ML 164/99       */
/*      <mr99164@alas.matf.bg.ac.yu>      */
/*   Milan Skaric,        MR 266/98       */
/*   Vladimir Raskovic,   MR 254/99       */
/*   Obrad Radosavljevic, ML 200/99       */
/******************************************/

#ifndef __elmember_h
#define __elmember_h

#include "object.h"

class ELMember : public Object {
public:
    ELMember( Object *o );
    ELMember( Object *o, const char *nm );
    ~ELMember();
    virtual void doInLoop(void *arg);
};

#endif
///////////////////////////////////////////////////
// $Id: list.h,v 1.5 2000/11/11 09:21:26 straxy Exp $
//
// MathASM Copyleft 2000 Strahinja Radic.
//
// LIST.H - Definicija & deklaracija klase Lista
//
///////////////////////////////////////////////////

#ifndef __list_h
#define __list_h

#ifndef NULL
#define NULL ((void *) 0)
#endif

#ifdef HAVE_CONFIG_H
#include "../config.h"
#endif
#ifdef HAVE_STREAM_H
#include <stream.h>
#endif

template <class T>
    struct list_element {
	T *data;
	list_element<T> *next, *prev;
    
	list_element() { data = NULL; next = prev = NULL; }
	list_element(T t) { data = new T; *data = t; next = prev = NULL; }
	list_element(list_element<T> &l)
	    {
		data = new T; *data = *l.data;
		prev = next = NULL;
	    }
	~list_element() { if (data) delete data; }
    };

/*template <class T>
typedef tagELEM list_element;*/

template <class T>
    class list {
	public:
    list()
	{
	    len = 0;

	    head = new list_element<T>;
	    tail = new list_element<T>;
            
	    head->prev = tail->next = (list_element<T> *)NULL;
	    head->next = tail;
	    tail->prev = head;
	}
        
    list(const list<T> *l)
	{
	    len = 0;

	    head = new list_element<T>;
	    tail = new list_element<T>;
            
	    head->prev = tail->next = NULL;
	    head->next = tail;
	    tail->prev = head;

	    if (l)
		for (int i = 0; i < l->len; i++)
		    if ((*l)[i]) add(*(*l)[i]);
	}
        
    ~list()
	{
	    for (list_element<T> *victim = head->next; victim != tail;
		 victim = victim->next)
		if (victim->prev)
		    delete victim->prev;
	    delete tail;
	    len = 0;
	}
        
    int add(const T &newval) {
	list_element<T> *newel = new list_element<T>;
	newel->data = new T;
	*(newel->data) = newval;
	newel->prev = tail->prev;
	newel->next = tail;
	newel->prev->next = newel;
	tail->prev = newel;
	len++;
	return 1;
    }
        
    int addAt(const T &newval, int pos)
	{
	    if (outOfBounds(pos))
		return 0;
            
	    list_element<T> *newel = new list_element<T>;
	    list_element<T> *temp;
	    newel->data = new T;
	    *newel->data = newval;
    
	    if (len) {
		temp = getAt(pos);
		newel->prev = temp->prev;
		newel->next = temp;
		if (temp->prev) temp->prev->next = newel;
		temp->prev = newel;
	    } else {
		newel->prev = head;
		newel->next = tail;
		head->next = newel;
		tail->prev = newel;
	    }
	    len++;
	    return 1;
	}
        
    int removeAt(int pos)
	{
	    if (outOfBounds(pos))
		return 0;
	    list_element<T> *temp = getAt(pos);
	    if (temp->prev) temp->prev->next = temp->next;
	    if (temp->next) temp->next->prev = temp->prev;
	    delete temp;
	    return 1;
	}
        
    inline const int length() const { return len; }
        
    list_element<T> *getAt(int pos) const
	{
	    if (outOfBounds(pos))
		return (list_element<T> *)NULL;
                
	    list_element<T> *temp;
	    int counter;
                
	    if (pos < len/2) {
		temp = head->next; counter = 0;
		while (temp != tail && counter != pos) {
		    temp = temp->next;
		    counter++;
		}
	    } else {
		temp = tail->prev; counter = len-1;
		while (temp != head && counter != pos) {
		    temp = temp->prev;
		    counter--;
		}
	    }
	    return temp;
	}
        
    T * operator[](int pos) const
	{
	    if (outOfBounds(pos))
		return (T *)NULL;
	    list_element<T> *temp = getAt(pos);
	    return temp->data;
	}
        
    inline int outOfBounds(int pos) const
	{ return (pos < 0 || pos > len); }
        
    void forEach(int (*f)(T &, void *), void *arg)
	{
	    if (!f) return;
    
	    for (list_element<T> *current = head->next; current != tail;
		 current = current->next)
		if (!(*f)(*current->data, arg)) break;
	}
        
    T *firstThat(int (*f)(T &, void *), void *arg)
	{
	    if (!f) return NULL;

	    for (list_element<T> *current = head->next; current != tail;
		 current = current->next)
		if ((*f)(*current->data, arg))
		    return current->data;
	    return NULL;
	}
        
	private:
        list_element<T> *head, *tail;
        int len;
};

#endif
/* -*- C++ -*- */
/******************************************/
/* P A H U L J E (c) 2001                 */
/*----------------------------------------*/
/*   Strahinja Radic,     ML 164/99       */
/*      <mr99164@alas.matf.bg.ac.yu>      */
/*   Milan Skaric,        MR 266/98       */
/*   Vladimir Raskovic,   MR 254/99       */
/*   Obrad Radosavljevic, ML 200/99       */
/******************************************/

#ifndef __object_h
#define __object_h

#include <string.h>

enum Compare { GT, GE, EQ, LE, LT };

typedef Compare (*compare_f)(void *, void *, void *);
typedef bool (*criteria_f)(void *, void *);
typedef void (*callback_f)(void *);

class Object {
public:
    Object(Object *ow, const char *nm);
    virtual ~Object();
    virtual void freeMe();
    void setName(const char *newn);
    void setOwner(Object *newow);
    inline const char *getName() { return name; }
    inline const Object *getOwner() { return owner; }
private:
    Object *owner;
    char *name;
};

#endif
/* -*- C++ -*- */
/******************************************/
/* P A H U L J E (c) 2001                 */
/*----------------------------------------*/
/*   Strahinja Radic,     ML 164/99       */
/*      <mr99164@alas.matf.bg.ac.yu>      */
/*   Milan Skaric,        MR 266/98       */
/*   Vladimir Raskovic,   MR 254/99       */
/*   Obrad Radosavljevic, ML 200/99       */
/******************************************/

#ifndef __pahulje_h
#define __pahulje_h

#include "screen.h"

extern const char *helpLine;
extern const color_t helpColor;

void help(Screen& s);

enum Polje { PRAZNO, IKS, OKS, T_IKS, T_OKS };

enum Status { IGRAC1, IGRAC2, NERESENO, NISTA };

class Pahulje {
public:
    Pahulje(Screen *s);
    ~Pahulje() { ; }
    void pocni();
    void getIme1(char **i);
    void getIme2(char **i);
    void setIme1(const char *i);
    void setIme2(const char *i);
private:
    Screen *sc;
    char *igrac1, *igrac2;
    Polje tabla[8][8];
    Status status;
    void drawPos(Screen& s, const coord_t col, const coord_t pre,
		 const coord_t startx, const coord_t starty,
		 const bool iksOks);
    void gameOver(Screen& s, const Status stat);
    bool tableFull();
    int findFree(const coord_t col);
    Status getStatus(const coord_t startx, const coord_t starty);
};

#endif
/* -*- C++ -*- */
/******************************************/
/* P A H U L J E (c) 2001                 */
/*----------------------------------------*/
/*   Strahinja Radic,     ML 164/99       */
/*      <mr99164@alas.matf.bg.ac.yu>      */
/*   Milan Skaric,        MR 266/98       */
/*   Vladimir Raskovic,   MR 254/99       */
/*   Obrad Radosavljevic, ML 200/99       */
/******************************************/

#ifndef __screen_h
#define __screen_h

#include <sys/time.h>
#include <ncurses.h>
#include <string.h>
#include <stdlib.h>
#include <limits.h>
#include "object.h"

typedef int color_t;
typedef unsigned char coord_t;
typedef int key_t;
typedef chtype chr_t;

// Colors
const color_t clBlack   = COLOR_BLACK;
const color_t clYellow  = COLOR_YELLOW;
const color_t clBlue    = COLOR_BLUE;
const color_t clRed     = COLOR_RED;
const color_t clWhite   = COLOR_WHITE;
const color_t clGreen   = COLOR_GREEN;
const color_t clMagenta = COLOR_MAGENTA;
const color_t clCyan    = COLOR_CYAN;

const int nColors = 8;

// Graphic chars
#define chVLine    ACS_VLINE
#define chHLine    ACS_HLINE
#define chURCorner ACS_URCORNER
#define chULCorner ACS_ULCORNER
#define chDRCorner ACS_LRCORNER
#define chDLCorner ACS_LLCORNER
#define chUT       ACS_TTEE
#define chRT       ACS_RTEE
#define chLT       ACS_LTEE
#define chDT       ACS_BTEE
#define chCross    ACS_PLUS

// getCh() codes
const key_t   kbUp      = KEY_UP;
const key_t   kbDown    = KEY_DOWN;
const key_t   kbRight   = KEY_RIGHT;
const key_t   kbLeft    = KEY_LEFT;
const key_t   kbHome    = KEY_HOME;
const key_t   kbEnd     = KEY_END;
#ifndef CTRL
#define CTRL(x) ((x) & 0x1f)
#endif
const key_t   kbEsc     = CTRL('[');
const key_t   kbEnter   = 0xD;    // Non-portable

extern bool *pairs;

struct ScreenField {
    chr_t data;
    color_t bg;
    color_t fg;
    bool modified;
    int attrs;
};

class Screen : public Object {
public:
    Screen(Object *o, const bool db = true,
	   const coord_t w = 80, const coord_t h = 25 );
    Screen(Object *o, const char *nm, const bool db = true,
	   const coord_t w = 80, const coord_t h = 25 );
    virtual ~Screen();
    inline const char *screenType() { return type; }
    virtual void freeMe();
    void gotoXY(const coord_t x, const coord_t y);
    void setDoubleBuff(const bool onoff = true);
    void setColor(const color_t fg, const color_t bg = clBlack);
    void setBlink(const bool onoff = true);
    void setBright(const bool onoff = true);
    void setReverse(const bool onoff = true);
    color_t randomColor(const unsigned int seed = 0);
    void outChar(const chr_t c);
    void outCharXY(const chr_t c, const coord_t x, const coord_t y);
    void outText(const char *text);
    void outTextXY(const char *text, const coord_t x, const coord_t y);
    key_t getCh();
    void clrScr();
    coord_t whereX();
    coord_t whereY();
    void drawMatrix(const coord_t startx, const coord_t starty,
		    const coord_t rows, const coord_t cols);
    inline coord_t getWidth()  { return width;  }
    inline coord_t getHeight() { return height; }
    void cursorOn();
    void cursorOff();
    void getText(char **s, const int n);
    void update();
private:
    char *type;
    int attrs;
    bool doubleBuff;
    unsigned int ourSeed;
    ScreenField *map;
    color_t defFg, defBg;
    color_t currentBg, currentFg;
    coord_t cx, cy;
    coord_t width;
    coord_t height;
    void __initScreen(const bool db);
    void Refresh();
    void set_color(const color_t fg, const color_t bg);
    void initScreenField(ScreenField *sf);
};

#endif
/* -*- C++ -*- */
/******************************************/
/* P A H U L J E (c) 2001                 */
/*----------------------------------------*/
/*   Strahinja Radic,     ML 164/99       */
/*      <mr99164@alas.matf.bg.ac.yu>      */
/*   Milan Skaric,        MR 266/98       */
/*   Vladimir Raskovic,   MR 254/99       */
/*   Obrad Radosavljevic, ML 200/99       */
/******************************************/

#ifndef __timer_h
#define __timer_h

#include <sys/time.h>
#include <unistd.h>
#include "elmember.h"


#ifndef time_t
typedef long int time_t;
#endif

class Time {
public:
    Time()
	: sec(0), msec(0) {;}
    Time(Time& t);
    Time(time_t s, time_t ms)
	: sec(s), msec(ms) {;}
    time_t sec;
    time_t msec;
    bool operator==(const Time& t);
    bool operator>(const Time& t);
    bool operator<(const Time& t);
    bool operator<=(const Time& t);
    bool operator>=(const Time& t);
    Time& operator=(const Time& t);
    Time  operator+(const Time& t);
    //Time  operator-();
    Time  operator-(const Time& t);
    Time& operator+=(const Time& t);
    Time& operator-=(const Time& t);
    void getNow();
private:
    void normalize();
};

void tmcpy(Time& t, long sec, long msec);

class Timer : public ELMember {
public:
    Timer( Object *o, callback_f f );
    Timer( Object *o, const char *nm, callback_f f );
    virtual ~Timer();
    virtual void freeMe();
    void setTime(const Time& newt);
    const Time& getTime();
    void reset();
    void start();
    void stop();
    Time period();
    void doInLoop(void *arg);
    inline bool isActive() { return active; }
public:
    callback_f onTimer;
    Time startTime;
    Time endTime;
    bool active;
};

#endif
/* -*- C++ -*- */
/******************************************/
/* P A H U L J E (c) 2001                 */
/*----------------------------------------*/
/*   Strahinja Radic,     ML 164/99       */
/*      <mr99164@alas.matf.bg.ac.yu>      */
/*   Milan Skaric,        MR 266/98       */
/*   Vladimir Raskovic,   MR 254/99       */
/*   Obrad Radosavljevic, ML 200/99       */
/******************************************/

#ifndef __wincontrol_h
#define __wincontrol_h

#include "object.h"

class WinControl : public Object {
public:
  WinControl( Object *o );
  WinControl( Object *o, const char *nm );
  virtual ~WinControl();
  virtual void freeMe();
  inline const int getTop() { return top; }
  inline const int getLeft() { return left; }
  inline const int getWidth() { return width; }
  inline const int getHeight() { return height; }
  inline void setTop(const int nt)    { top    = nt; }
  inline void setLeft(const int nl)   { left   = nl; }
  inline void setWidth(const int nw)  { width  = nw; }
  inline void setHeight(const int nh) { height = nh; }
  inline void setPosition(const int t, const int l,
			  const int w, const int h)
  {
    setTop(t); setLeft(l); setWidth(w); setHeight(h);
  }
  virtual void show();
  virtual void hide();
  inline void setVisible(const bool nv) { visible = nv; }
  void setShowing( const Object *sender, const bool onoff );
  void addComponent( WinControl *obj );
private:
  int top, left, width, height;
  bool visible, showing;
  WinControl *parent;
};

#endif
/* -*- C++ -*- */
/******************************************/
/* P A H U L J E (c) 2001                 */
/*----------------------------------------*/
/*   Strahinja Radic,     ML 164/99       */
/*      <mr99164@alas.matf.bg.ac.yu>      */
/*   Milan Skaric,        MR 266/98       */
/*   Vladimir Raskovic,   MR 254/99       */
/*   Obrad Radosavljevic, ML 200/99       */
/******************************************/

#include "elmember.h"

ELMember::ELMember( Object *o )
    : Object( o, "ELMember" )
{
}

ELMember::ELMember( Object *o, const char *nm )
    : Object( o, nm )
{
}

ELMember::~ELMember()
{
    freeMe();
}

void ELMember::doInLoop(void *arg)
{
    return;
}
/* -*- C++ -*- */
/******************************************/
/* P A H U L J E (c) 2001                 */
/*----------------------------------------*/
/*   Strahinja Radic,     ML 164/99       */
/*      <mr99164@alas.matf.bg.ac.yu>      */
/*   Milan Skaric,        MR 266/98       */
/*   Vladimir Raskovic,   MR 254/99       */
/*   Obrad Radosavljevic, ML 200/99       */
/******************************************/

#include "list.h"

template <class T>
    List<T>::List( Object *o, int delta = 10 )
	: Object( o, "List" ), numElements(0), allocated(0),
	  data(NULL)
{
}

template <class T>
    List<T>::List( Object *o, const char *nm, int delta = 10 )
	: Object( o, nm ), numElements(0), allocated(0),
	  data(NULL)
{
}

template <class T>
    List<T>::~List()
{
    freeMe();
}


template <class T>
    void List<T>::freeMe()
{
    if (data) delete data;
}

template <class T>
    void List<T>::add(const T t)
{
    ListItem<T> *newdata, *temp;
    
    if (!allocated) {
	data = new ListItem<T>[(allocated=delta+1)];
    } else if (numElements+1 > allocated) {
	newdata = new ListItem<T>[(allocated=allocated+delta)];
	
	for (i = 0; i < numElements; i++)
	    newdata[i] = data[i];

	temp = data;
	data = newdata;

	delete temp;
    }

    newdata[++numElements] = ListItem<T>(t);
}

template <class T>
    void List<T>::remove(const int idx)
{
    data[idx].removed = true;
}

template <class T>
    void List<T>::clear()
{
    delete data;
    data = NULL;
    allocated = numElements = 0;
}

template <class T>
    void List<T>::compact()
{
    ListItem<T> *newdata, *temp;
    
    newdata = new ListItem<T>[(allocated
		     = ((int)(numElements/delta)+1)*delta)];

    for (i=0; i < numElements; i++)
	newdata[i] = data[i];

    temp = data;
    data = newdata;

    delete temp;
}

//-------------- ListIterator
template <class T>
    ListIterator<T>::ListIterator( Object *o, List<T> *l )
	: Object( o, "ListIterator" ), myList(l), index(0)
{
}

template <class T>
    ListIterator<T>::ListIterator( Object *o, const char *nm, List<T> *l )
	: Object( o, nm ), myList(l), index(0)
{
}

template <class T>
    ListIterator<T>::~ListIterator()
{
    freeMe();
}

template <class T>
    void ListIterator<T>::freeMe()
{
    ;
}

template <class T>
    ListItem<T> *ListIterator<T>::first()
{
    return *this[0];
}

template <class T>
    ListItem<T> *ListIterator<T>::last()
{
    return *this[myList->numElements];
}

template <class T>
    ListItem<T> *ListIterator<T>::next()
{
    if (index+1 > myList->numElements)
	return NULL;
    return *this[++index];
}

template <class T>
    ListItem<T> *ListIterator<T>::prev()
{
    if (index-1 < 0)
	return NULL;
    return *this[--index];
}

template <class T>
    T& ListIterator<T>::operator[](const int i)
{
    int idx = 0, ridx = 0;

    while (idx < myList->numElements && idx != i) {
	if ( !(myList->data[ridx].removed) )
	    idx++;
	ridx++;
    }

    if (idx == myList->allocated)
	return error;

    return *(myList->data[ridx].data);
}

template <class T>
    ListItem<T>* ListIterator<T>::operator++()    // prefix
{
    return next();
}

template <class T>
    ListItem<T>* ListIterator<T>::operator++(int) // postfix
{
    return next();
}

template <class T>
    ListItem<T>* ListIterator<T>::operator--()    // prefix
{
    return prev();
}

template <class T>
    ListItem<T>* ListIterator<T>::operator--(int) // postfix
{
    return prev();
}
