/*
 * SDLScreen.cpp
 *
 *  Created on: 20.02.2012
 *      Author: Strahinja
 */

#include <iostream>
#include "SDLScreen.h"

using namespace std;

SDLScreen::SDLScreen()
: width(640), height(480), depth(32), title("SDL Application")
{
	SDL_Init(SDL_INIT_EVERYTHING);
	SDL_WM_SetCaption(title.c_str(), NULL);
	refresh();
}

SDLScreen::SDLScreen(int w, int h, int d)
: width(w), height(h), depth(d), title("SDL Application")
{
	//cout << "SDLScreen(w, h, d)" << endl;
	SDL_Init(SDL_INIT_EVERYTHING);
	SDL_WM_SetCaption(title.c_str(), NULL);
	refresh();
}

SDLScreen::SDLScreen(int w, int h, string t, int d)
: width(w), height(h), depth(d), title(t)
{
	//cout << "SDLScreen(w, h, t, d)" << endl;
	SDL_Init(SDL_INIT_EVERYTHING);
	SDL_WM_SetCaption(title.c_str(), NULL);
	refresh();
}

SDLScreen::~SDLScreen()
{
	//cout << "~SDLScreen()" << endl;
	SDL_Quit();
}

const int
SDLScreen::getWidth() const
{
	return width;
}

void
SDLScreen::setWidth(int w)
{
	width = w;
}

const int
SDLScreen::getHeight() const
{
	return height;
}

void
SDLScreen::setHeight(int h)
{
	height = h;
}

const int
SDLScreen::getDepth() const
{
	return depth;
}

void
SDLScreen::setDepth(int d)
{
	depth = d;
}

const string
SDLScreen::getTitle() const
{
	return title;
}

void
SDLScreen::setTitle(string t)
{
	title = t;
}

void
SDLScreen::setTitle(char* t)
{
	if (t != NULL)
	{
		title = t;
	}
}

void
SDLScreen::refresh()
{
	//cout << "SDLScreen::refresh()" << endl;
	screen = SDL_SetVideoMode(width, height, depth, SDL_HWSURFACE
			//| SDL_OPENGL
			// | SDL_FULLSCREEN
			);
	//SDL_SetAlpha(screen, SDL_SRCALPHA, 255);
	//cout << "screen->Amask=" << (int)screen->format->Amask << endl;
}

SDL_Surface*
SDLScreen::getSurface()
{
	return screen;
}

SDLScreen&
SDLScreen::operator=(const SDLScreen& source)
{
	//cout << "SDLScreen::operator=()" << endl;
	if (screen != NULL)
	{
		//cout << "freeing surface" << endl;
		SDL_FreeSurface(screen);
		//cout << "success!" << endl;
	}
	width = source.getWidth();
	height = source.getHeight();
	depth = source.getDepth();
	title = source.getTitle();
	refresh();
	return *this;
}
