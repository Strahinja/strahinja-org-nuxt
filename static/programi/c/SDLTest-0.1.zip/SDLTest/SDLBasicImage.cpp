/*
 * SDLBasicImage.cpp
 *
 *  Created on: 20.02.2012
 *      Author: Strahinja
 */

#include "SDLBasicImage.h"

SDLBasicImage::SDLBasicImage()
: image(NULL)
{
}

SDLBasicImage::SDLBasicImage(string fileName)
{
	load(fileName);
}

SDLBasicImage::~SDLBasicImage()
{
	if (image != NULL)
	{
		SDL_FreeSurface(image);
	}
}

void
SDLBasicImage::load(string fileName)
{
	SDL_Surface* loadedImage = SDL_LoadBMP(fileName.c_str());
	if (loadedImage != NULL)
	{
		image = SDL_DisplayFormat(loadedImage);
		SDL_FreeSurface(loadedImage);
	}
}

void
SDLBasicImage::draw(int x, int y, SDL_Surface* destination)
{
	SDL_Rect offset;
	offset.x = x;
	offset.y = y;
	SDL_BlitSurface(image, NULL, destination, &offset);
}
