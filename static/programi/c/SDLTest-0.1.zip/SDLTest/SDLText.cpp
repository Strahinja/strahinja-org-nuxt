/*
 * SDLText.cpp
 *
 *  Created on: 22.02.2012
 *      Author: Strahinja
 */


#include "SDLText.h"

#include <math.h>
#include <iostream>
using namespace std;

bool SDLText::ttfLibInitialized = false;

SDLText::SDLText()
: fontName(""), fontSize(10), text(""), font(NULL), textSurface(NULL),
  shadowSurface(NULL), effect(sdlteNone), shadowDeltaX(3), shadowDeltaY(3),
  opacity(1.0f)
{
	if (!SDLText::ttfLibInitialized)
	{
		SDLText::ttfLibInitialized = true;
		TTF_Init();
	}
	fontColor.r = 0;
	fontColor.g = 0;
	fontColor.b = 0;

	// grey shadow by default
	shadowColor.r = 128;
	shadowColor.g = 128;
	shadowColor.b = 128;
}

SDLText::SDLText(string fn, int fs, string t)
: fontName(fn), fontSize(fs), text(t), shadowSurface(NULL), effect(sdlteNone),
  shadowDeltaX(3), shadowDeltaY(3), opacity(1.0f)
{
	if (!ttfLibInitialized)
	{
		ttfLibInitialized = true;
		TTF_Init();
	}

	loadFont();

	fontColor.r = 0;
	fontColor.g = 0;
	fontColor.b = 0;

	// grey shadow by default
	shadowColor.r = 128;
	shadowColor.g = 128;
	shadowColor.b = 128;

	render();
}

SDLText::~SDLText()
{
	if (textSurface != NULL)
	{
		SDL_FreeSurface(textSurface);
	}

	if (shadowSurface != NULL)
	{
		SDL_FreeSurface(shadowSurface);
	}

	if (font != NULL)
	{
		TTF_CloseFont(font);
	}

	// TODO: How to keep track for TTF_Quit()?
}

string
SDLText::getFontName() const
{
    return fontName;
}

int
SDLText::getFontSize() const
{
    return fontSize;
}

SDL_Color
SDLText::getFontColor() const
{
	return fontColor;
}

SDL_Color
SDLText::getShadowColor() const
{
	return shadowColor;
}

string
SDLText::getText() const
{
    return text;
}

SDLTextEffect
SDLText::getEffect() const
{
	return effect;
}

int
SDLText::getShadowDeltaX() const
{
	return shadowDeltaX;
}

int
SDLText::getShadowDeltaY() const
{
	return shadowDeltaY;
}

void
SDLText::setFontName(string fontName)
{
    this->fontName = fontName;
    //loadFont(fontName);
}

void
SDLText::setFontSize(int fontSize)
{
    this->fontSize = fontSize;
}

void
SDLText::setFontColor(Uint8 r, Uint8 g, Uint8 b)
{
	this->fontColor.r = r;
	this->fontColor.g = g;
	this->fontColor.b = b;
}

void
SDLText::setFontColor(SDL_Color c)
{
	this->fontColor.r = c.r;
	this->fontColor.g = c.g;
	this->fontColor.b = c.b;
}

void
SDLText::setShadowColor(Uint8 r, Uint8 g, Uint8 b)
{
	this->shadowColor.r = r;
	this->shadowColor.g = g;
	this->shadowColor.b = b;
}

void
SDLText::setShadowColor(SDL_Color c)
{
	this->shadowColor.r = c.r;
	this->shadowColor.g = c.g;
	this->shadowColor.b = c.b;
}

void
SDLText::setShadowDelta(int x, int y)
{
	shadowDeltaX = x;
	shadowDeltaY = y;
}

void
SDLText::setText(string text)
{
    this->text = text;
}

void
SDLText::setEffect(SDLTextEffect te)
{
	effect = te;
}

int
SDLText::getFontHeight() const
{
	if (font != NULL)
	{
		return TTF_FontHeight(font);
	}
	else
	{
		return 0;
	}
}

int
SDLText::getTextWidth() const
{
	int width;
	//cout << "TTF_SizeUTF8() for text " << text.c_str() << endl;
	//cout << "font = " << (int)font << endl;
	TTF_SizeUTF8(font, text.c_str(), &width, NULL);
	//cout << "ok" << endl;
	//cout << "getting width of text \"" << text << "\": " << width << endl;
	return width;
}

int
SDLText::getTextHeight() const
{
	int height;
	TTF_SizeUTF8(font, text.c_str(), NULL, &height);
	//cout << "getting height of text \"" << text << "\": " << height << endl;
	return height;
}

void
SDLText::setOpacity(float o)
{
	opacity = o;
}

float
SDLText::getOpacity() const
{
	return opacity;
}

void
SDLText::loadFont()
{
	font = TTF_OpenFont(fontName.c_str(), fontSize);
}

void
SDLText::render()
{
	//cout << "SDLText::render() [" << text << "]" << endl;
	if (font == NULL)
	{
		//cout << "font == NULL, exiting" << endl;
		return;
	}
	textSurface = TTF_RenderText_Solid(font, text.c_str(), fontColor);
	//cout << "TTF_RenderText_Solid() done" << endl;
	if (effect == sdlteShadowText)
	{
		//cout << "text is shadowed, rendering shadow" << endl;
		shadowSurface = TTF_RenderText_Solid(font, text.c_str(), shadowColor);
	}
	else
	{
		//cout << "text is not shadowed" << endl;
	}
}

void
SDLText::draw(int x, int y, SDL_Surface* canvas)
{
	SDL_Rect offset;
	bool applyOpacity = false;

	if (fabsf(opacity - 1.0f) > _SDLTEXT_H_EPSILON)
	{
		applyOpacity = true;
	}

	if (textSurface != NULL)
	{
		if (effect == sdlteShadowText && shadowSurface != NULL)
		{
			if (applyOpacity)
			{
				//cout << "setting shadow opacity to " << fixed << opacity << endl;
				SDL_SetAlpha(shadowSurface, SDL_SRCALPHA, (int)(255 * opacity));
			}
			offset.x = x + shadowDeltaX;
			offset.y = y + shadowDeltaY;
			SDL_BlitSurface(shadowSurface, NULL, canvas, &offset);
		}

		if (applyOpacity)
		{
			//cout << "setting opacity to " << fixed << opacity << endl;
			SDL_SetAlpha(textSurface, SDL_SRCALPHA, (int)(255 * opacity));
		}
		offset.x = x;
		offset.y = y;
		SDL_BlitSurface(textSurface, NULL, canvas, &offset);
	}
}
