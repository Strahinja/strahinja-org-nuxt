/*
 * SDLMenuTestApp.h
 *
 *  Created on: 07.03.2012.
 *      Author: Strahinja
 */

#ifndef SDLMENUTESTAPP_H_
#define SDLMENUTESTAPP_H_

#include "SDLApplication.h"
#include "SDLMenuItemNewGame.h"
#include "SDLMenuItemExit.h"
#include "SDLMenu.h"
#include "SDLImage.h"

class SDLMenuTestApp: public SDLApplication {
private:
	SDLImage* image;
	SDLMenu* menu;
	int deltaX;
	SDLMenuItemNewGame* newGameItem;
	SDLMenuItemExit* exitItem;
public:
	SDLMenuTestApp();
	virtual ~SDLMenuTestApp();
	void onRender();
	void onDraw();
	void onLoop();
	void onEvents(SDL_Event* evt);
};

#endif /* SDLMENUTESTAPP_H_ */
