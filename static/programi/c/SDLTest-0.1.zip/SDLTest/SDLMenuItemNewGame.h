/*
 * SDLMenuItemNewGame.h
 *
 *  Created on: 07.03.2012.
 *      Author: Strahinja
 */

#ifndef SDLMENUITEMNEWGAME_H_
#define SDLMENUITEMNEWGAME_H_

#include "SDLText.h"
#include "SDLMenuItem.h"

class SDLMenuItemNewGame: public SDLMenuItem {
private:
	bool messageActive;
	SDLText* message;
	int direction;
public:
	SDLMenuItemNewGame();
	virtual ~SDLMenuItemNewGame();
	void onActivate(SDLApplication* app);
	void onDraw(int x, int y, SDL_Surface* canvas);
};

#endif /* SDLMENUITEMNEWGAME_H_ */
