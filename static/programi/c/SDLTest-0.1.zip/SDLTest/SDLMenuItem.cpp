/*
 * SDLMenuItem.cpp
 *
 *  Created on: 07.03.2012.
 *      Author: Strahinja
 */

#include "SDLMenuItem.h"

SDLMenuItem::SDLMenuItem()
{
	label = new SDLText();
}

SDLMenuItem::~SDLMenuItem()
{
	delete label;
}

SDLText*
SDLMenuItem::getLabel()
{
	return label;
}

void
SDLMenuItem::onRender()
{
	label->render();
}

void
SDLMenuItem::onDraw(int x, int y, SDL_Surface* canvas)
{
	label->draw(x, y, canvas);
}

void
SDLMenuItem::onActivate(SDLApplication* app)
{
	//cout << "SDLMenuItem::onActivate()" << endl;
}
