/*
 * SDLScreen.h
 *
 *  Created on: 20.02.2012
 *      Author: Strahinja
 */

#ifndef SDLSCREEN_H_
#define SDLSCREEN_H_

#include <string>
#include "SDL/SDL.h"

using namespace std;

class SDLScreen {
private:
	int width;
	int height;
	int depth;
	string title;
	SDL_Surface* screen;
public:
	SDLScreen();
	SDLScreen(int w, int h, int d = 32);
	SDLScreen(int w, int h, string t, int d = 32);
	const int getWidth() const;
	void setWidth(int w);
	const int getHeight() const;
	void setHeight(int h);
	const int getDepth() const;
	void setDepth(int d);
	const string getTitle() const;
	void setTitle(string t);
	void setTitle(char* t);
	void refresh();
	SDL_Surface* getSurface();
	virtual ~SDLScreen();
	SDLScreen& operator=(const SDLScreen& source);
};

#endif /* SDLSCREEN_H_ */
