/*
 * SDLMenuItemNewGame.cpp
 *
 *  Created on: 07.03.2012.
 *      Author: Strahinja
 */

#include "SDLMenuItemNewGame.h"

#include <math.h>

SDLMenuItemNewGame::SDLMenuItemNewGame()
: SDLMenuItem(), messageActive(false), direction(1)
{
	getLabel()->setText("New game");
	message = new SDLText("NK211.otf", 15, "Starting new game!");
	message->setFontColor(255, 255, 120);
	message->setShadowColor(0,0,0);
	message->setEffect(sdlteShadowText);
	message->setShadowDelta(1,1);
	message->render();
}

SDLMenuItemNewGame::~SDLMenuItemNewGame()
{
	delete message;
}

void
SDLMenuItemNewGame::onActivate(SDLApplication* app)
{
	//cout << "newGame::onActivate()" << endl;
	//cout << "messageActive = " << messageActive << endl;
	messageActive = !messageActive;
}

void
SDLMenuItemNewGame::onDraw(int x, int y, SDL_Surface* canvas)
{
	SDLMenuItem::onDraw(x, y, canvas);
	if (messageActive)
	{
		if (fabsf(message->getOpacity() - 1.0f) < _SDLTEXT_H_EPSILON)
		{
			direction = -1;
		}
		else if (fabsf(message->getOpacity()) < _SDLTEXT_H_EPSILON)
		{
			direction = 1;
		}
		//cout << "NewGame::onDraw() [direction = " << direction << "]" << endl;
		//cout << "setting opacity" << endl;
		//cout << "old opacity = " << fixed << message->getOpacity() << endl;
		message->setOpacity(message->getOpacity() + 0.01 * direction);
		//cout << "new opacity = " << fixed << message->getOpacity() << endl;
		message->draw(canvas->w / 2 - message->getTextWidth() / 2,
				20, canvas);
	}
}
