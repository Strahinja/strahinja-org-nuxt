/*
 * SDLApplication.cpp
 *
 *  Created on: 07.03.2012.
 *      Author: Strahinja
 */

#include "SDLApplication.h"

SDLApplication::SDLApplication()
: active(false), screen(NULL), keystates(NULL), mod(KMOD_NONE)
{
	//cout << "SDLApp()" << endl;
}

SDLApplication::SDLApplication(SDLScreen* screen)
: active(false), keystates(NULL), mod(KMOD_NONE)
{
	//cout << "SDLApp(screen)" << endl;
	if (screen != NULL)
	{
		*(this->screen) = *screen;
	}
	else
	{
		screen = NULL;
	}
}

SDLApplication::~SDLApplication()
{
	//cout << "~SDLApp()" << endl;
}

void
SDLApplication::setActive(bool to)
{
	active = to;
}

bool
SDLApplication::getActive() const
{
	return active;
}

SDL_Surface*
SDLApplication::getScreen()
{
	if (screen != NULL)
	{
		return screen->getSurface();
	}
	else
	{
		return NULL;
	}
}

int
SDLApplication::run()
{
	SDL_Event evt;

	//cout << "SDLApp::run()" << endl;

	setActive(true);
	onRender();
	while (active)
	{
		while (SDL_PollEvent(&evt))
		{
			onEvents(&evt);
		}
		onDraw();
		if (screen != NULL)
		{
			SDL_Flip(screen->getSurface());
			//SDL_GL_SwapBuffers();
		}
		onLoop();
	}
	setActive(false);
	return 0;
}

void
SDLApplication::onEvents(SDL_Event* evt)
{
	//cout << "SDLApp::onEvents()" << endl;
	//switch (evt->type)
	//{
	//case SDL_KEYDOWN:
	//case SDL_KEYUP:
	keystates = SDL_GetKeyState(NULL);
	mod = SDL_GetModState();
	//	break;
	//}
}

void
SDLApplication::onLoop()
{
	//cout << "SDLApp::onLoop()" << endl;
}

void
SDLApplication::onRender()
{
	//cout << "SDLApp::onRender()" << endl;
}

void
SDLApplication::onDraw()
{
	//cout << "SDLApp::onDraw()" << endl;
}
