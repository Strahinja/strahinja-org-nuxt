/*
 * SDLImage.cpp
 *
 *  Created on: 20.02.2012
 *      Author: Strahinja
 */

#include "SDLImage.h"

SDLImage::SDLImage()
: SDLBasicImage()
{
	//cout << "SDLImage()" << endl;
}

SDLImage::SDLImage(string fileName)
: SDLBasicImage()
{
	//cout << "SDLImage(string)" << endl;
	load(fileName);
}

SDLImage::~SDLImage()
{
	//cout << "~SDLImage()" << endl;
}

void
SDLImage::load(string fileName)
{
	//cout << "SDLImage::load(string)" << endl;
	SDL_Surface* loadedImage = IMG_Load(fileName.c_str());
	//cout << "IMG_Load(char*) ok" << endl;
	if (loadedImage != NULL)
	{
		//cout << "calling SDL_DisplayFormat()" << endl;
		image = SDL_DisplayFormat(loadedImage);
		//cout << "SDL_DisplayFormat() ok" << endl;
		//cout << "calling SDL_FreeSurface()" << endl;
		SDL_FreeSurface(loadedImage);
		//cout << "FreeSurface() ok" << endl;
	}
	//cout << "load() ok" << endl;
}

int
SDLImage::getWidth() const
{
	if (image != NULL)
	{
		return image->w;
	}
	else
	{
		return -1;
	}
}

int SDLImage::getHeight() const
{
	if (image != NULL)
	{
		return image->h;
	}
	else
	{
		return -1;
	}
}
