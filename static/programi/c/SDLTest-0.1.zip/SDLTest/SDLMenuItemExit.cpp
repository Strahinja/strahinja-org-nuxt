/*
 * SDLMenuItemExit.cpp
 *
 *  Created on: 07.03.2012.
 *      Author: Strahinja
 */

#include "SDLMenuItemExit.h"

SDLMenuItemExit::SDLMenuItemExit()
: SDLMenuItem()
{
	getLabel()->setText("Exit");
}

SDLMenuItemExit::~SDLMenuItemExit()
{
}

void
SDLMenuItemExit::onActivate(SDLApplication* app)
{
	app->setActive(false);
}
