/*
 * SDLText.h
 *
 *  Created on: 22.02.2012
 *      Author: Strahinja
 */

#ifndef SDLTEXT_H_
#define SDLTEXT_H_

#include <string>
#include "SDL/SDL.h"
#include "SDL/SDL_ttf.h"

using namespace std;

#define _SDLTEXT_H_EPSILON 1e-5f

enum SDLTextEffect {
	sdlteNone,
	sdlteShadowText
};

class SDLText {
private:
	string fontName;
	int fontSize;
	SDL_Color fontColor;
	SDL_Color shadowColor;
	string text;
	TTF_Font* font;
	static bool ttfLibInitialized;
	SDL_Surface* textSurface;
	SDL_Surface* shadowSurface;
	SDLTextEffect effect;
	int shadowDeltaX;
	int shadowDeltaY;
	float opacity;
public:
	SDLText();
	SDLText(string fn, int fs, string t);
	virtual ~SDLText();
    string getFontName() const;
    int getFontSize() const;
    SDL_Color getFontColor() const;
    SDL_Color getShadowColor() const;
    string getText() const;
    SDLTextEffect getEffect() const;
    int getShadowDeltaX() const;
    int getShadowDeltaY() const;
    void setFontName(string fontName);
    void setFontSize(int fontSize);
    void setFontColor(Uint8 r, Uint8 g, Uint8 b);
    void setFontColor(SDL_Color c);
    void setShadowColor(Uint8 r, Uint8 g, Uint8 b);
    void setShadowColor(SDL_Color c);
    void setShadowDelta(int x, int y);
    void setText(string text);
    void setEffect(SDLTextEffect te);
    int getFontHeight() const;
    int getTextWidth() const;
    int getTextHeight() const;
    void setOpacity(float o);
    float getOpacity() const;
    virtual void loadFont();
    virtual void render();
    void draw(int x, int y, SDL_Surface* canvas);
};

#endif /* SDLTEXT_H_ */
