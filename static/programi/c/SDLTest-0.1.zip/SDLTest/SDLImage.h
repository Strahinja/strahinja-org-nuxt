/*
 * SDLImage.h
 *
 *  Created on: 20.02.2012
 *      Author: Strahinja
 */

#ifndef SDLIMAGE_H_
#define SDLIMAGE_H_

#include <iostream>
#include "SDLBasicImage.h"
#include "SDL/SDL_image.h"

using namespace std;

class SDLImage: public SDLBasicImage {
public:
	SDLImage();
	SDLImage(string fileName);
	void load(string fileName);
	int getWidth() const;
	int getHeight() const;
	virtual ~SDLImage();
};

#endif /* SDLIMAGE_H_ */
