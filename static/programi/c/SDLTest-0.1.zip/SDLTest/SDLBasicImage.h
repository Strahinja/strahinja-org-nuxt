/*
 * SDLBasicImage.h
 *
 *  Created on: 20.02.2012
 *      Author: Strahinja
 */

#ifndef SDLBASICIMAGE_H_
#define SDLBASICIMAGE_H_

#include <string>
#include <iostream>
#include "SDL/SDL.h"

using namespace std;

class SDLBasicImage {
protected:
	SDL_Surface* image;
public:
	SDLBasicImage();
	SDLBasicImage(string fileName);
	virtual void load(string fileName);
	void draw(int x, int y, SDL_Surface* destination);
	virtual ~SDLBasicImage();
};

#endif /* SDLBASICIMAGE_H_ */
