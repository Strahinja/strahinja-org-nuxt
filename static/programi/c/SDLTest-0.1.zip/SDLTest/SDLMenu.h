/*
 * SDLMenu.h
 *
 *  Created on: 24.02.2012
 *      Author: Strahinja
 */

#ifndef SDLMENU_H_
#define SDLMENU_H_

#include <list>
#include <string>
#include "SDL/SDL.h"
#include "SDLApplication.h"
#include "SDLMenuItem.h"

using namespace std;

class SDLMenu {
private:
	SDLApplication* app;
	list<SDLMenuItem*>* items;
	string fontName;
	int fontSize;
	SDLTextEffect effect;
	SDL_Rect bounds;
	int itemPadding;
	int currentItem;
	Uint32 selectionColor;
	SDL_Surface* selectionCanvas;
	SDL_Rect* selectionRect;
	float selectionOpacity;
	bool visibility;
public:
	SDLMenu(SDLApplication* app);
	SDLMenu(SDLApplication* app, string fn);
	virtual ~SDLMenu();
	list<SDLMenuItem*>* getItems();
	void addItem(string title);
	void addItem(SDLMenuItem* item);
	string getFontName() const;
	void setFontName(string n);
	int getFontSize() const;
	void setFontSize(int s);
	SDLTextEffect getEffect() const;
	void setEffect(SDLTextEffect e);
	const SDL_Rect* getBounds() const;
	void setBounds(int left, int top, int width, int height);
	int getItemPadding() const;
	void setItemPadding(int g);
	int getMaxItemWidth() const;
	SDLMenuItem* getItemAt(size_t pos);
	SDL_Rect* getItemRect(size_t item);
	SDL_Rect* getItemRect(SDLMenuItem* item);
	void selectItem(size_t item);
	size_t getActiveItem() const;
	void setSelectionColor(SDL_Color c);
	void setSelectionColorRGB(int r, int g, int b);
	void setSelectionColorRGBA(int r, int g, int b, int a);
	SDL_Color* getSelectionColor() const;
	Uint32 getSelectionColorUint32() const;
	float getSelectionOpacity() const;
	void setSelectionOpacity(float o);
	void setVisibility(bool v);
	bool isVisible() const;
	void onKey(Uint8* keystates, SDLMod mod);
	void render();
	void draw(SDL_Surface* canvas);
};

#endif /* SDLMENU_H_ */
