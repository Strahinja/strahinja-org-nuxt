/*
 * SDLMenuItem.h
 *
 *  Created on: 07.03.2012.
 *      Author: Strahinja
 */

#ifndef SDLMENUITEM_H_
#define SDLMENUITEM_H_

#include "SDLApplication.h"
#include "SDLText.h"

class SDLMenuItem {
private:
	SDLText* label;
public:
	SDLMenuItem();
	virtual ~SDLMenuItem();
	SDLText* getLabel();
	virtual void onActivate(SDLApplication* app);
	virtual void onRender();
	virtual void onDraw(int x, int y, SDL_Surface* canvas);
};

#endif /* SDLMENUITEM_H_ */
