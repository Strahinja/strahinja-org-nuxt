/*
 * SDLMenuTestApp.cpp
 *
 *  Created on: 07.03.2012.
 *      Author: Strahinja
 */

#include "SDLMenuTestApp.h"

SDLMenuTestApp::SDLMenuTestApp()
: SDLApplication(), deltaX(0)
{
	int menuHeight;
	//cout << "SDLMenuTestApp()" << endl;
	screen = new SDLScreen(800, 600, "SDL Menu Test Application", 32);

	// http://stockfresh.com/image/281692/seamless-repeatable-rattan-reed-cane-wicker-or-straw-mat-pattern
	image = new SDLImage("bg.jpg");

	menu = new SDLMenu(this);
	menu->setFontName("NK211.otf");
	menu->setFontSize(36);
	menu->setEffect(sdlteShadowText);
	newGameItem = new SDLMenuItemNewGame();
	menu->addItem(newGameItem);
	menu->addItem("Load game");
	menu->addItem("Save game");
	exitItem = new SDLMenuItemExit();
	//cout << "exitItem created" << endl;
	menu->addItem(exitItem);
	//cout << "exitItem added" << endl;
	menu->setItemPadding(8);
	menu->setSelectionOpacity(0.6);
	menu->setSelectionColorRGB(255, 255, 120);
	menuHeight = menu->getItemRect((size_t)0)->h * menu->getItems()->size();
	menu->setBounds(
			screen->getWidth() / 2 - menu->getMaxItemWidth() / 2,
			screen->getHeight() / 2 - menuHeight / 2,
			menu->getMaxItemWidth(),
			menuHeight
			);
			//200, 100, 200, 600);
}

SDLMenuTestApp::~SDLMenuTestApp()
{
	//cout << "~SDLMenuTestApp()" << endl;
}

void
SDLMenuTestApp::onRender()
{
	//cout << "SDLMenuTestApp::onRender()" << endl;
	menu->render();
}

void
SDLMenuTestApp::onDraw()
{
	//cout << "SDLMenuTestApp::onDraw()" << endl;
	if (image != NULL)
	{
		if (deltaX > 0)
		{
			image->draw(deltaX-image->getWidth(), 0, screen->getSurface());
			image->draw(deltaX-image->getWidth(), image->getHeight(), screen->getSurface());
		}
		image->draw(deltaX, 0, screen->getSurface());
		image->draw(image->getWidth() + deltaX, 0, screen->getSurface());
		image->draw(deltaX, image->getHeight(), screen->getSurface());
		image->draw(image->getWidth() + deltaX, image->getHeight(), screen->getSurface());
	}

	menu->draw(screen->getSurface());
}

void
SDLMenuTestApp::onLoop()
{
	//cout << "SDLMenuTestApp::onLoop()" << endl;
	deltaX++;
	if (deltaX == image->getWidth())
	{
		deltaX = 0;
	}
	SDL_Delay(10);
}

void
SDLMenuTestApp::onEvents(SDL_Event* evt)
{
	//cout << "SDLMenuTestApp::onEvents()" << endl;
	SDLApplication::onEvents(evt);

	if (evt->type == SDL_KEYDOWN || evt->type == SDL_KEYUP)
	{
		if (keystates[SDLK_ESCAPE])
		{
			menu->setVisibility(!menu->isVisible());
		}
		else if (keystates[SDLK_q] && (mod & KMOD_CTRL))
		{
			setActive(false);
		}

		if (menu->isVisible())
		{
			menu->onKey(keystates, mod);
		}
	}
}
