/*
 * SDLMenuItemExit.h
 *
 *  Created on: 07.03.2012.
 *      Author: Strahinja
 */

#ifndef SDLMENUITEMEXIT_H_
#define SDLMENUITEMEXIT_H_

#include "SDLMenuItem.h"

class SDLMenuItemExit: public SDLMenuItem {
public:
	SDLMenuItemExit();
	virtual ~SDLMenuItemExit();
	void onActivate(SDLApplication* app);
};

#endif /* SDLMENUITEMEXIT_H_ */
