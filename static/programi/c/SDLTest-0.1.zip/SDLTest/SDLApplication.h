/*
 * SDLApplication.h
 *
 *  Created on: 07.03.2012.
 *      Author: Strahinja
 */

#ifndef SDLAPPLICATION_H_
#define SDLAPPLICATION_H_

#include "SDL/SDL.h"
#include "SDLScreen.h"

#include <iostream>
using namespace std;

class SDLApplication {
protected:
	bool active;
	SDLScreen* screen;
	Uint8* keystates;
	SDLMod mod;
public:
	SDLApplication();
	SDLApplication(SDLScreen* screen);
	virtual ~SDLApplication();
	void setActive(bool to);
	bool getActive() const;
	SDL_Surface* getScreen();
	virtual int run();
	virtual void onEvents(SDL_Event* evt);
	virtual void onLoop();
	virtual void onRender();
	virtual void onDraw();
};

#endif /* SDLAPPLICATION_H_ */
