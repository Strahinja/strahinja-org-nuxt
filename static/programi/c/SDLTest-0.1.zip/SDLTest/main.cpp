/*
 * main.cpp
 *
 *  Created on: 20.02.2012
 *      Author: Strahinja
 */

#include <iostream>
#include "SDLMenuTestApp.h"
/*#include "SDLScreen.h"
#include "SDLImage.h"
#include "SDLText.h"
#include "SDLMenu.h"
#include "SDL/SDL.h"*/

using namespace std;

int
main(int argc, char **argv)
{
	/*
	SDL_Surface* screen = SDL_SetVideoMode(640, 480, 32, SDL_HWSURFACE);
	SDL_VideoInfo* info = (SDL_VideoInfo*)SDL_GetVideoInfo();
	SDL_Surface* layer = SDL_CreateRGBSurface(SDL_HWSURFACE, 100, 100,
			info->vfmt->BitsPerPixel,
			info->vfmt->Rmask,
			info->vfmt->Gmask,
			info->vfmt->Bmask,
			info->vfmt->Amask
			);
	SDL_Rect rect;

	rect.x = 0;
	rect.y = 0;
	rect.w = 100;
	rect.h = 100;

	Uint32 blue = SDL_MapRGB(info->vfmt, 0, 0, 255);
	SDL_FillRect(layer, &rect, blue);
	SDL_BlitSurface(layer, NULL, screen, NULL);
	SDL_Flip(screen);
	SDL_Delay(3000);
	return 0;*/

	// TODO: Call SDL_FreeSurface() for each SDL_Surface()

	SDLMenuTestApp app;
	return app.run();
}
