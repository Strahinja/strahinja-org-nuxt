/*
 * SDLMenu.cpp
 *
 *  Created on: 24.02.2012
 *      Author: Strahinja
 */

#include "SDLMenu.h"

#include <iostream>
using namespace std;

SDLMenu::SDLMenu(SDLApplication* app)
: app(app), items(NULL), fontName(""), fontSize(10), effect(sdlteNone),
  itemPadding(5), selectionCanvas(NULL), selectionRect(NULL),
  selectionOpacity(1.0f), visibility(true)
{
	items = new list<SDLMenuItem*>();
	setSelectionColorRGB(255, 255, 255);
}

SDLMenu::SDLMenu(SDLApplication* app, string fn)
: app(app), items(NULL), fontName(fn),
  itemPadding(5), selectionCanvas(NULL), selectionRect(NULL),
  selectionOpacity(1.0f), visibility(true)
{
	items = new list<SDLMenuItem*>();
	setSelectionColorRGB(255, 255, 255);
}

SDLMenu::~SDLMenu()
{
	if (items != NULL)
	{
		delete items;
	}
}

list<SDLMenuItem*>*
SDLMenu::getItems()
{
	return items;
}

void
SDLMenu::addItem(SDLMenuItem* item)
{
	SDLText* itemLabel = item->getLabel();

	if (item == NULL)
	{
		return;
	}

	//cout << "Adding item \"" << itemLabel->getText() << "\"" << endl;

	itemLabel->setFontName(fontName);
	itemLabel->setFontSize(fontSize);
	itemLabel->loadFont();
	itemLabel->setEffect(effect);

	if (items->empty())
	{
		currentItem = 0;
	}

	items->push_back(item);
}

void
SDLMenu::addItem(string title)
{
	SDLMenuItem* newItem = new SDLMenuItem();
	newItem->getLabel()->setText(title);
	addItem(newItem);
	/*cout << "After push_back():" << endl;
	for (list<SDLText*>::iterator i = items->begin();
			i != items->end(); i++)
	{
		cout << (*i)->getText() << endl;
	}
	cout << "End of list" << endl;*/
}

string
SDLMenu::getFontName() const
{
	return fontName;
}

void
SDLMenu::setFontName(string n)
{
	fontName = n;
}

int
SDLMenu::getFontSize() const
{
	return fontSize;
}

void
SDLMenu::setFontSize(int s)
{
	fontSize = s;
}

SDLTextEffect
SDLMenu::getEffect() const
{
	return effect;
}

void
SDLMenu::setEffect(SDLTextEffect e)
{
	effect = e;
}

const SDL_Rect*
SDLMenu::getBounds() const
{
	return &bounds;
}

void
SDLMenu::setBounds(int left, int top, int width, int height)
{
	bounds.x = left;
	bounds.y = top;
	bounds.w = width;
	bounds.h = height;
}

int
SDLMenu::getItemPadding() const
{
	return itemPadding;
}

void
SDLMenu::setItemPadding(int g)
{
	itemPadding = g;
}

SDLMenuItem*
SDLMenu::getItemAt(size_t pos)
{
	list<SDLMenuItem*>::iterator i = items->begin();
	size_t current = 0;
	while (current != pos && i != items->end())
	{
		i++;
		current++;
	}
	if (i == items->end() && current != pos)
	{
		return NULL;
	}
	else
	{
		return *i;
	}
}

SDL_Rect*
SDLMenu::getItemRect(size_t item)
{
	static SDL_Rect rect;
	size_t current = 0;

	//cout << "getItemRect(int) called for item \"" << item << "\"" << endl;

	rect.x = bounds.x;
	rect.y = bounds.y;
	rect.w = 0;
	rect.h = 0;

	list<SDLMenuItem*>::iterator i = items->begin();

	while (current != item && i != items->end())
	{
		if (current != item)
		{
			rect.y += (*i)->getLabel()->getTextHeight() + 2 * itemPadding;
			i++;
			current++;
		}
	}

	if (i == items->end() && current != item)
	{
		return NULL;
	}
	else
	{
		rect.w = (*i)->getLabel()->getTextWidth() + 2 * itemPadding;
		rect.h = (*i)->getLabel()->getTextHeight() + 2 * itemPadding;
		return &rect;
	}
}

SDL_Rect*
SDLMenu::getItemRect(SDLMenuItem* item)
{
	static SDL_Rect rect;
	bool found = false;

	//cout << "getItemRect(SDLText*) called for item \"" << item->getText() << "\"" << endl;

	rect.x = bounds.x;
	rect.y = bounds.y;
	rect.w = 0;
	rect.h = 0;

	list<SDLMenuItem*>::iterator i = items->begin();

	while (!found && i != items->end())
	{
		if (*i == item)
		{
			rect.w = (*i)->getLabel()->getTextWidth() + 2 * itemPadding;
			rect.h = (*i)->getLabel()->getTextHeight() + 2 * itemPadding;
			found = true;
		}
		else
		{
			rect.y += (*i)->getLabel()->getTextHeight() + 2 * itemPadding;
			i++;
		}
	}

	if (found)
	{
		return &rect;
	}
	else
	{
		return NULL;
	}
}

void
SDLMenu::selectItem(size_t item)
{
	if (items->size() > 0)
	{
		currentItem = item % items->size();
	}
	/*if (item < (int)items->size())
	{
		currentItem = item;
	}*/
}

size_t
SDLMenu::getActiveItem() const
{
	return currentItem;
}

void
SDLMenu::setSelectionColor(SDL_Color c)
{
	SDL_VideoInfo* info = (SDL_VideoInfo*)SDL_GetVideoInfo();
	/*cout << "setSelectionColor(): info->vfmt->BitsPerPixel="
			<< (int)info->vfmt->BitsPerPixel << endl;*/
	selectionColor = SDL_MapRGB(info->vfmt, c.r, c.g, c.b);
}

void
SDLMenu::setSelectionColorRGB(int r, int g, int b)
{
	SDL_VideoInfo* info = (SDL_VideoInfo*)SDL_GetVideoInfo();
	/*cout << "setSelectionColorRGB(): info->vfmt->BitsPerPixel="
			<< (int)info->vfmt->BitsPerPixel << endl;*/
	selectionColor = SDL_MapRGB(info->vfmt, r, g, b);
}

void
SDLMenu::setSelectionColorRGBA(int r, int g, int b, int a)
{
	SDL_VideoInfo* info = (SDL_VideoInfo*)SDL_GetVideoInfo();
	/*cout << "setSelectionColorRGB(): info->vfmt->BitsPerPixel="
			<< (int)info->vfmt->BitsPerPixel << endl;*/
	selectionColor = SDL_MapRGBA(info->vfmt, r, g, b, a);
}

SDL_Color*
SDLMenu::getSelectionColor() const
{
	static SDL_Color color;
	SDL_VideoInfo* info = (SDL_VideoInfo*)SDL_GetVideoInfo();
	SDL_GetRGB(selectionColor, info->vfmt, &color.r, &color.g, &color.b);
	return &color;
}

Uint32
SDLMenu::getSelectionColorUint32() const
{
	return selectionColor;
}

float
SDLMenu::getSelectionOpacity() const
{
	return selectionOpacity;
}

void
SDLMenu::setSelectionOpacity(float o)
{
	selectionOpacity = o;
}

void
SDLMenu::setVisibility(bool v)
{
	visibility = v;
}

bool
SDLMenu::isVisible() const
{
	return visibility;
}

void
SDLMenu::onKey(Uint8* keystates, SDLMod mod)
{
	if (keystates[SDLK_DOWN] || keystates[SDLK_s])
	{
		selectItem(getActiveItem() + 1);
		render();
	}
	else if (keystates[SDLK_UP] || keystates[SDLK_w])
	{
		selectItem(getActiveItem() - 1);
		render();
	}
	else if (keystates[SDLK_RETURN])
	{
		getItemAt(currentItem)->onActivate(app);
	}
}

void
SDLMenu::render()
{
	//cout << "SDLMenu::render()" << endl;
	SDLMenuItem* current = NULL;
	SDL_VideoInfo* info = NULL;
	SDL_Rect fillRect;

	if (!items->empty())
	{
		info = (SDL_VideoInfo*)SDL_GetVideoInfo();
		//cout << "calling getItemAt()" << endl;
		current = getItemAt(currentItem);
		//cout << "getItemAt() ok, current = " << current->getLabel()->getText() << endl;
		//cout << "getItemRect()" << endl;
		selectionRect = getItemRect(current);
		//cout << "ok" << endl;
		//optional - make the selection rect as wide as the widest item
		//cout << "getMaxItemWidth()" << endl;
		selectionRect->w = getMaxItemWidth() + 2 * itemPadding;
		//cout << "ok" << endl;

		//cout << "SDL_CreateRGBSurface()" << endl;
		selectionCanvas = SDL_CreateRGBSurface(SDL_HWSURFACE,
				selectionRect->w, selectionRect->h,
				info->vfmt->BitsPerPixel,
				info->vfmt->Rmask,
				info->vfmt->Gmask,
				info->vfmt->Bmask,
				info->vfmt->Amask);
		//cout << "ok" << endl;
		//SDL_SetPalette(selectionCanvas, 0, s->format->palette->colors, 0, s->format->palette->ncolors);
		/*SDL_SetAlpha(selectionCanvas, 0, 0);
		SDL_SetColorKey(selectionCanvas, SDL_SRCCOLORKEY, SDL_MapRGB(selectionCanvas->format,
				1,1,1));
		selectionCanvas = SDL_DisplayFormatAlpha(selectionCanvas);*/
		//

		fillRect.x = 0;
		fillRect.y = 0;
		fillRect.w = selectionRect->w;
		fillRect.h = selectionRect->h;
		SDL_FillRect(selectionCanvas, &fillRect, selectionColor);
		SDL_SetAlpha(selectionCanvas, SDL_SRCALPHA, (int)(255 * selectionOpacity));

		//SDL_SaveBMP(selectionCanvas, "selection.bmp");
		//cout << "render(): selectionColor=" << selectionColor << endl;
	}

	//cout << "rendering items..." << endl;
	for (list<SDLMenuItem*>::iterator i = items->begin();
			i != items->end(); i++)
	{
		(*i)->onRender();
	}
}

int
SDLMenu::getMaxItemWidth() const
{
	int maxWidth = 0;
	int currentWidth = 0;
	for (list<SDLMenuItem*>::iterator i = items->begin();
			i != items->end(); i++)
	{
		//cout << "determining width for item "
		//		<< (*i)->getLabel()->getText() << endl;
		currentWidth = (*i)->getLabel()->getTextWidth();
		//cout << "ok" << endl;
		if (currentWidth > maxWidth)
		{
			maxWidth = currentWidth;
		}
	}
	return maxWidth;
}

void
SDLMenu::draw(SDL_Surface* canvas)
{
	int currentY = bounds.y;

	if (!visibility)
	{
		return;
	}

	//cout << "draw() called" << endl;

	if (selectionCanvas != NULL)
	{
		SDL_BlitSurface(selectionCanvas, NULL, canvas, selectionRect);
	}

	for (list<SDLMenuItem*>::iterator i = items->begin();
			i != items->end(); i++)
	{
		(*i)->onDraw(bounds.x + itemPadding, currentY + itemPadding, canvas);
		currentY += (*i)->getLabel()->getTextHeight() + itemPadding * 2;
	}
}
